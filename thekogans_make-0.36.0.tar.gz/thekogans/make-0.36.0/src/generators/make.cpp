// Copyright 2011 Boris Kogan (boris@thekogans.net)
//
// This file is part of thekogans_make.
//
// thekogans_make is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// thekogans_make is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with thekogans_make. If not, see <http://www.gnu.org/licenses/>.

#include <set>
#include <iostream>
#include <fstream>
#include <locale>
#include "thekogans/util/Types.h"
#include "thekogans/util/ByteSwap.h"
#include "thekogans/util/Directory.h"
#include "thekogans/util/File.h"
#include "thekogans/util/Path.h"
#include "thekogans/make/core/Function.h"
#include "thekogans/make/core/thekogans_make.h"
#include "thekogans/make/core/Project.h"
#include "thekogans/make/core/Utils.h"
#if defined (THEKOGANS_MAKE_CORE_HAVE_CURL)
    #include "thekogans/make/core/Sources.h"
#endif // defined (THEKOGANS_MAKE_CORE_HAVE_CURL)
#include "thekogans/make/generators/make.h"

namespace thekogans {
    namespace make {
        namespace generators {

            THEKOGANS_UTIL_IMPLEMENT_DYNAMIC_CREATABLE (make, Generator::TYPE)

            namespace {
                void DumpFileLists (
                        std::fstream &stream,
                        const std::vector<core::thekogans_make::FileList::SharedPtr> &fileLists,
                        const core::thekogans_make &thekogans_make,
                        std::list<core::thekogans_make::FileList::File::CustomBuild::SharedPtr> &customBuildList) {
                    for (auto fileList : fileLists) {
                        std::string namePrefix = core::MakePath (thekogans_make.project_root, fileList->prefix);
                        std::string outputPrefix =
                            core::MakePath (
                                core::MakePath (
                                    thekogans_make.project_root,
                                    core::GetBuildDirectory (
                                        thekogans_make.generator,
                                        thekogans_make.config,
                                        thekogans_make.type)),
                                fileList->prefix);
                        for (auto file : fileList->files) {
                            std::string name = core::MakePath (namePrefix, file->name);
                            stream << "\\\n  " << name;
                            if (file->customBuild != nullptr) {
                                core::thekogans_make::FileList::File::CustomBuild::SharedPtr customBuild (
                                    new core::thekogans_make::FileList::File::CustomBuild (
                                        file->customBuild->message,
                                        file->customBuild->recipe));
                                for (auto output : file->customBuild->outputs) {
                                    customBuild->outputs.push_back (core::MakePath (outputPrefix, output));
                                }
                                customBuild->dependencies.push_back (name);
                                std::string dependencyPrefix = core::MakePath (thekogans_make.project_root, fileList->prefix);
                                for (auto dependency : file->customBuild->dependencies) {
                                    customBuild->dependencies.push_back (core::MakePath (dependencyPrefix, dependency));
                                }
                                customBuildList.push_back (std::move (customBuild));
                            }
                        }
                    }
                }

                std::string GetVariable (
                        const char **buffer,
                        const char delimiters[] = "()") {
                    const char *ptr = *buffer;
                    if (*ptr != delimiters[0]) {
                        THEKOGANS_UTIL_THROW_STRING_EXCEPTION (
                            "Invalid variable declaration in: %s", ptr);
                    }
                    ++ptr;
                    std::string variable;
                    while (*ptr != '\0' && *ptr != delimiters[1]) {
                        variable += *ptr++;
                    }
                    if (*ptr != delimiters[1]) {
                        THEKOGANS_UTIL_THROW_STRING_EXCEPTION (
                            "Invalid variable declaration in: %s", ptr);
                    }
                    *buffer = ++ptr;
                    return variable;
                }

                void GetLines (
                        const std::string &str,
                        std::vector<std::string> &lines) {
                    std::string::size_type newLine;
                    std::string::size_type start = 0;
                    const char *NEW_LINE_CHARS = "\r\n";
                    while ((newLine = str.find_first_of (NEW_LINE_CHARS, start)) != std::string::npos) {
                        // Line ending conventions.
                        // POSIX - '\n'
                        // OS X - '\r'
                        // Windows - '\r\n'
                        // If we're processing an '\r\n' file, remove both endings.
                        if (str[start] == '\r' && start < str.size () - 1 && str[start + 1] == '\n') {
                            ++start;
                        }
                        std::string line =
                            util::TrimRightSpaces (str.substr (start, newLine - start).c_str ());
                        if (!line.empty ()) {
                            lines.push_back (line);
                        }
                        start = newLine + 1;
                    }
                    std::string line = util::TrimRightSpaces (str.substr (start).c_str ());
                    if (!line.empty ()) {
                        lines.push_back (line);
                    }
                }

                bool IsContinuation (const std::string &str) {
                    return !str.empty () && str.back () == '\\';
                }

                const char *makefileTemplate =
                    "# This file was automatically generated by thekogans_make. DO NOT EDIT!\n"
                    "organization := $(organization)\n"
                    "project := $(project)\n"
                    "project_type := $(project_type)\n"
                    "major_version := $(major_version)\n"
                    "minor_version := $(minor_version)\n"
                    "patch_version := $(patch_version)\n"
                    "naming_convention := $(naming_convention)\n"
                    "config := $(config)\n"
                    "type := $(type)\n"
                    "runtime_type := $(runtime_type)\n"
                    "\n"
                    "include $(TOOLCHAIN_ROOT)/common/resources/make.rules.top\n"
                    "\n"
                    "goal := $(goal)\n"
                    "dependencies_goals := $(dependencies_goals)\n"
                    "include_directories := $(include_directories)\n"
                    "library_directories := $(library_directories)\n"
                    "framework_directories := $(framework_directories)\n"
                    "linker_flags := $(linker_flags)\n"
                    "librarian_flags := $(librarian_flags)\n"
                    "link_libraries := $(link_libraries)\n"
                    "common_preprocessor_definitions := $(common_preprocessor_definitions)\n"
                    "features := $(features)\n"
                    "masm_flags := $(masm_flags)\n"
                    "masm_preprocessor_definitions := $(masm_preprocessor_definitions)\n"
                    "masm_headers := $(masm_headers)\n"
                    "masm_sources := $(masm_sources)\n"
                    "masm_tests := $(masm_tests)\n"
                    "nasm_flags := $(nasm_flags)\n"
                    "nasm_preprocessor_definitions := $(nasm_preprocessor_definitions)\n"
                    "nasm_headers := $(nasm_headers)\n"
                    "nasm_sources := $(nasm_sources)\n"
                    "nasm_tests := $(nasm_tests)\n"
                    "c_flags := $(c_flags)\n"
                    "c_preprocessor_definitions := $(c_preprocessor_definitions)\n"
                    "c_headers := $(c_headers)\n"
                    "c_sources := $(c_sources)\n"
                    "c_tests := $(c_tests)\n"
                    "cpp_flags := $(cpp_flags)\n"
                    "cpp_preprocessor_definitions := $(cpp_preprocessor_definitions)\n"
                    "cpp_headers := $(cpp_headers)\n"
                    "cpp_sources := $(cpp_sources)\n"
                    "cpp_tests := $(cpp_tests)\n"
                    "objective_c_flags := $(objective_c_flags)\n"
                    "objective_c_preprocessor_definitions := $(objective_c_preprocessor_definitions)\n"
                    "objective_c_headers := $(objective_c_headers)\n"
                    "objective_c_sources := $(objective_c_sources)\n"
                    "objective_c_tests := $(objective_c_tests)\n"
                    "objective_cpp_flags := $(objective_cpp_flags)\n"
                    "objective_cpp_preprocessor_definitions := $(objective_cpp_preprocessor_definitions)\n"
                    "objective_cpp_headers := $(objective_cpp_headers)\n"
                    "objective_cpp_sources := $(objective_cpp_sources)\n"
                    "objective_cpp_tests := $(objective_cpp_tests)\n"
                    "resources := $(resources)\n"
                    "rc_flags := $(rc_flags)\n"
                    "rc_preprocessor_definitions := $(rc_preprocessor_definitions)\n"
                    "rc_sources := $(rc_sources)\n"
                    "subsystem := $(subsystem)\n"
                    "def_file := $(def_file)\n"
                    "\n"
                    "$(custom_build_rules)\n"
                    "\n"
                    "include $(TOOLCHAIN_ROOT)/common/resources/make.rules.bottom\n";
            }

            namespace {
                struct to_build_system_path : public core::Function {
                    THEKOGANS_UTIL_DECLARE_DYNAMIC_CREATABLE (to_build_system_path)

                    virtual core::Value Exec (
                            const core::thekogans_make & /*thekogans_make*/,
                            const Parameters &parameters) const override {
                        std::string path;
                        for (auto parameter : parameters) {
                            if (parameter.first == "p" || parameter.first == "path") {
                                path = parameter.second;
                            }
                        }
                        return core::Value (path);
                    }
                };

                THEKOGANS_UTIL_IMPLEMENT_DYNAMIC_CREATABLE (to_build_system_path, Function::TYPE)
            }

            bool make::Generate (
                    const std::string &project_root,
                    const std::string &config,
                    const std::string &type,
                    bool generateDependencies,
                    bool force) {
                const core::thekogans_make &thekogans_make =
                    core::thekogans_make::GetConfig (
                        project_root,
                        THEKOGANS_MAKE_XML,
                        Type (),
                        config,
                        type);
                if (rootProject) {
                    thekogans_make.CheckDependencies ();
                }
                std::string makefileFilePath = ToSystemPath (
                    core::MakePath (
                        core::GetBuildRoot (project_root, Type (), config, type),
                        MAKEFILE));
                bool makefileFilePathExists = util::Path (makefileFilePath).Exists ();
                time_t makefileFilePathLastModifiedDate = 0;
                if (makefileFilePathExists) {
                    makefileFilePathLastModifiedDate =
                        util::Directory::Entry (makefileFilePath).lastModifiedDate;
                }
                bool updatedDependency = false;
                if (generateDependencies) {
                    if (thekogans_make.project_type == PROJECT_TYPE_PLUGIN) {
                        for (auto plugin_host : thekogans_make.plugin_hosts) {
                            if (plugin_host->GetConfigFile () == THEKOGANS_MAKE_XML) {
                                make dependency (false);
                                updatedDependency =
                                    dependency.Generate (
                                        plugin_host->GetProjectRoot (),
                                        plugin_host->GetConfig (),
                                        plugin_host->GetType (),
                                        generateDependencies,
                                        force) ||
                                    updatedDependency ||
                                    !makefileFilePathExists ||
                                    makefileFilePathLastModifiedDate <
                                    util::Directory::Entry (
                                        ToSystemPath (
                                            core::MakePath (
                                                core::GetBuildRoot (
                                                    plugin_host->GetProjectRoot (),
                                                    Type (),
                                                    plugin_host->GetConfig (),
                                                    plugin_host->GetType ()),
                                                MAKEFILE))).lastModifiedDate;
                            }
                        }
                    }
                    for (auto dependency : thekogans_make.dependencies) {
                        if (dependency->GetConfigFile () == THEKOGANS_MAKE_XML) {
                            make dependency_ (false);
                            updatedDependency =
                                dependency_.Generate (
                                    dependency->GetProjectRoot (),
                                    dependency->GetConfig (),
                                    dependency->GetType (),
                                    generateDependencies,
                                    force) ||
                                updatedDependency ||
                                !makefileFilePathExists ||
                                makefileFilePathLastModifiedDate <
                                util::Directory::Entry (
                                    ToSystemPath (
                                        core::MakePath (
                                            core::GetBuildRoot (
                                                dependency->GetProjectRoot (),
                                                Type (),
                                                dependency->GetConfig (),
                                                dependency->GetType ()), MAKEFILE))).lastModifiedDate;
                        }
                    }
                }
                std::string thekogans_makeFilePath =
                    ToSystemPath (core::MakePath (project_root, THEKOGANS_MAKE_XML));
                if (force ||
                        updatedDependency ||
                        !makefileFilePathExists ||
                    #if defined (THEKOGANS_MAKE_CORE_HAVE_CURL)
                        makefileFilePathLastModifiedDate <
                        util::Directory::Entry (
                            ToSystemPath (
                                core::MakePath (core::_TOOLCHAIN_ROOT, SOURCES_XML))).lastModifiedDate ||
                    #endif // defined (THEKOGANS_MAKE_CORE_HAVE_CURL)
                        makefileFilePathLastModifiedDate <
                        util::Directory::Entry (thekogans_makeFilePath).lastModifiedDate) {
                    std::cout << "Generating " <<
                        core::MakePath (
                            core::GetBuildRoot (project_root, Type (), config, type),
                            MAKEFILE) <<
                        std::endl;
                    std::cout.flush ();
                    core::CreateBuildRoot (project_root, Type (), config, type);
                    std::fstream makefileFile (
                        makefileFilePath.c_str (),
                        std::fstream::out | std::fstream::trunc);
                    if (makefileFile.is_open ()) {
                        std::list<core::thekogans_make::FileList::File::CustomBuild::SharedPtr> customBuildList;
                        const char *fileTemplate = makefileTemplate;
                        while (*fileTemplate != '\0') {
                            char ch = *fileTemplate++;
                            if (ch == '$') {
                                std::string variable = GetVariable (&fileTemplate);
                                if (variable == "organization") {
                                    makefileFile << thekogans_make.organization;
                                }
                                else if (variable == "project") {
                                    makefileFile << thekogans_make.project;
                                }
                                else if (variable == "project_type") {
                                    makefileFile << thekogans_make.project_type;
                                }
                                else if (variable == "major_version") {
                                    makefileFile << thekogans_make.major_version;
                                }
                                else if (variable == "minor_version") {
                                    makefileFile << thekogans_make.minor_version;
                                }
                                else if (variable == "patch_version") {
                                    makefileFile << thekogans_make.patch_version;
                                }
                                else if (variable == "naming_convention") {
                                    makefileFile << thekogans_make.naming_convention;
                                }
                                else if (variable == "config") {
                                    makefileFile << thekogans_make.config;
                                }
                                else if (variable == "type") {
                                    makefileFile << thekogans_make.type;
                                }
                                else if (variable == "runtime_type") {
                                #if defined (THEKOGANS_MAKE_USE_SHARED_RUNTIME)
                                    makefileFile << TYPE_SHARED;
                                #else // defined (THEKOGANS_MAKE_USE_SHARED_RUNTIME)
                                    makefileFile << thekogans_make.type;
                                #endif // defined (THEKOGANS_MAKE_USE_SHARED_RUNTIME)
                                }
                                else if (variable == "generator") {
                                    makefileFile << Type ();
                                }
                                else if (variable == "goal") {
                                    makefileFile << thekogans_make.GetProjectGoal ();
                                }
                                else if (variable == "dependencies_goals") {
                                    for (auto dependency : thekogans_make.dependencies) {
                                        if (dependency->GetConfigFile () == THEKOGANS_MAKE_XML) {
                                            makefileFile << "\\\n  " <<
                                                core::thekogans_make::GetConfig (
                                                    dependency->GetProjectRoot (),
                                                    dependency->GetConfigFile (),
                                                    dependency->GetGenerator (),
                                                    dependency->GetConfig (),
                                                    dependency->GetType ()).GetProjectGoal ();
                                        }
                                    }
                                }
                                else if (variable == "include_directories") {
                                    std::set<std::string> include_directories;
                                    thekogans_make.GetIncludeDirectories (include_directories);
                                    for (const auto &include_directory : include_directories) {
                                        makefileFile << "\\\n  " << include_directory;
                                    }
                                }
                                else if (variable == "library_directories") {
                                    std::set<std::string> library_directories;
                                    thekogans_make.GetLibraryDirectories (library_directories);
                                    for (const auto &library_directory : library_directories) {
                                        makefileFile << "\\\n  " << library_directory;
                                    }
                                }
                                else if (variable == "framework_directories") {
                                    std::set<std::string> framework_directories;
                                    thekogans_make.GetFrameworkDirectories (framework_directories);
                                    for (const auto &framework_directory : framework_directories) {
                                        makefileFile << "\\\n  " << framework_directory;
                                    }
                                }
                                else if (variable == "linker_flags") {
                                    std::set<std::string> linker_flags;
                                    thekogans_make.GetLinkerFlags (linker_flags);
                                    for (const auto &linker_flag : linker_flags) {
                                        makefileFile << "\\\n  " << linker_flag;
                                    }
                                    // ld needs to be able to locate the dependency libraries.
                                    if (thekogans_make.project_type == PROJECT_TYPE_PROGRAM &&
                                            core::_TOOLCHAIN_OS == "Linux" &&
                                            thekogans_make.type == TYPE_SHARED) {
                                        std::set<std::string> sharedLibraries;
                                        thekogans_make.GetSharedLibraries (sharedLibraries);
                                        for (auto sharedLibrary : sharedLibraries) {
                                            makefileFile << "\\\n  " << "-Wl,-rpath-link," << util::Path (sharedLibrary).GetDirectory ();
                                        }
                                    }
                                }
                                else if (variable == "librarian_flags") {
                                    std::set<std::string> librarian_flags;
                                    thekogans_make.GetLibrarianFlags (librarian_flags);
                                    for (auto librarian_flag : librarian_flags) {
                                        makefileFile << "\\\n  " << librarian_flag;
                                    }
                                }
                                else if (variable == "link_libraries") {
                                    std::vector<std::string> link_libraries;
                                    thekogans_make.GetLinkLibraries (link_libraries);
                                    for (const auto &link_library : link_libraries) {
                                        makefileFile << "\\\n  " << link_library;
                                    }
                                }
                                else if (variable == "common_preprocessor_definitions") {
                                    std::set<std::string> common_preprocessor_definitions;
                                    thekogans_make.GetCommonPreprocessorDefinitions (common_preprocessor_definitions);
                                    for (const auto &common_preprocessor_definition : common_preprocessor_definitions) {
                                        makefileFile << "\\\n  " << common_preprocessor_definition;
                                    }
                                }
                                else if (variable == "features") {
                                    std::set<std::string> features;
                                    thekogans_make.GetFeatures (features);
                                    for (const auto &feature : features) {
                                        makefileFile << "\\\n  " << feature;
                                    }
                                }
                                else if (variable == "masm_flags") {
                                    std::set<std::string> masm_flags;
                                    thekogans_make.GetMasmFlags (masm_flags);
                                    for (const auto &masm_flag : masm_flags) {
                                        makefileFile << "\\\n  " << masm_flag;
                                    }
                                }
                                else if (variable == "masm_preprocessor_definitions") {
                                    std::set<std::string> masm_preprocessor_definitions;
                                    thekogans_make.GetMasmPreprocessorDefinitions (masm_preprocessor_definitions);
                                    for (const auto &masm_preprocessor_definition : masm_preprocessor_definitions) {
                                        makefileFile << "\\\n  " << masm_preprocessor_definition;
                                    }
                                }
                                else if (variable == "masm_headers") {
                                    DumpFileLists (
                                        makefileFile,
                                        thekogans_make.masm_headers,
                                        thekogans_make,
                                        customBuildList);
                                }
                                else if (variable == "masm_sources") {
                                    DumpFileLists (
                                        makefileFile,
                                        thekogans_make.masm_sources,
                                        thekogans_make,
                                        customBuildList);
                                }
                                else if (variable == "masm_tests") {
                                    DumpFileLists (
                                        makefileFile,
                                        thekogans_make.masm_tests,
                                        thekogans_make,
                                        customBuildList);
                                }
                                else if (variable == "nasm_flags") {
                                    std::set<std::string> nasm_flags;
                                    thekogans_make.GetNasmFlags (nasm_flags);
                                    for (const auto &nasm_flag : nasm_flags) {
                                        makefileFile << "\\\n  " << nasm_flag;
                                    }
                                }
                                else if (variable == "nasm_preprocessor_definitions") {
                                    std::set<std::string> nasm_preprocessor_definitions;
                                    thekogans_make.GetNasmPreprocessorDefinitions (nasm_preprocessor_definitions);
                                    for (const auto &nasm_preprocessor_definition : nasm_preprocessor_definitions) {
                                        makefileFile << "\\\n  " << nasm_preprocessor_definition;
                                    }
                                }
                                else if (variable == "nasm_headers") {
                                    DumpFileLists (
                                        makefileFile,
                                        thekogans_make.nasm_headers,
                                        thekogans_make,
                                        customBuildList);
                                }
                                else if (variable == "nasm_sources") {
                                    DumpFileLists (
                                        makefileFile,
                                        thekogans_make.nasm_sources,
                                        thekogans_make,
                                        customBuildList);
                                }
                                else if (variable == "nasm_tests") {
                                    DumpFileLists (
                                        makefileFile,
                                        thekogans_make.nasm_tests,
                                        thekogans_make,
                                        customBuildList);
                                }
                                else if (variable == "c_flags") {
                                    std::set<std::string> c_flags;
                                    thekogans_make.GetCFlags (c_flags);
                                    for (const auto &c_flag : c_flags) {
                                        makefileFile << "\\\n  " << c_flag;
                                    }
                                }
                                else if (variable == "c_preprocessor_definitions") {
                                    std::set<std::string> c_preprocessor_definitions;
                                    thekogans_make.GetCPreprocessorDefinitions (c_preprocessor_definitions);
                                    for (const auto &c_preprocessor_definition :  c_preprocessor_definitions) {
                                        makefileFile << "\\\n  " << c_preprocessor_definition;
                                    }
                                }
                                else if (variable == "c_headers") {
                                    DumpFileLists (
                                        makefileFile,
                                        thekogans_make.c_headers,
                                        thekogans_make,
                                        customBuildList);
                                }
                                else if (variable == "c_sources") {
                                    DumpFileLists (
                                        makefileFile,
                                        thekogans_make.c_sources,
                                        thekogans_make,
                                        customBuildList);
                                }
                                else if (variable == "c_tests") {
                                    DumpFileLists (
                                        makefileFile,
                                        thekogans_make.c_tests,
                                        thekogans_make,
                                        customBuildList);
                                }
                                else if (variable == "cpp_flags") {
                                    std::set<std::string> cpp_flags;
                                    thekogans_make.GetCPPFlags (cpp_flags);
                                    for (const auto &cpp_flag :cpp_flags) {
                                        makefileFile << "\\\n  " << cpp_flag;
                                    }
                                }
                                else if (variable == "cpp_preprocessor_definitions") {
                                    std::set<std::string> cpp_preprocessor_definitions;
                                    thekogans_make.GetCPPPreprocessorDefinitions (cpp_preprocessor_definitions);
                                    for (const auto &cpp_preprocessor_definition :  cpp_preprocessor_definitions) {
                                        makefileFile << "\\\n  " << cpp_preprocessor_definition;
                                    }
                                }
                                else if (variable == "cpp_headers") {
                                    DumpFileLists (
                                        makefileFile,
                                        thekogans_make.cpp_headers,
                                        thekogans_make,
                                        customBuildList);
                                }
                                else if (variable == "cpp_sources") {
                                    DumpFileLists (
                                        makefileFile,
                                        thekogans_make.cpp_sources,
                                        thekogans_make,
                                        customBuildList);
                                }
                                else if (variable == "cpp_tests") {
                                    DumpFileLists (
                                        makefileFile,
                                        thekogans_make.cpp_tests,
                                        thekogans_make,
                                        customBuildList);
                                }
                                else if (variable == "objective_c_flags") {
                                    std::set<std::string> objective_c_flags;
                                    thekogans_make.GetObjectiveCFlags (objective_c_flags);
                                    for (const auto &objective_c_flag : objective_c_flags) {
                                        makefileFile << "\\\n  " << objective_c_flag;
                                    }
                                }
                                else if (variable == "objective_c_preprocessor_definitions") {
                                    std::set<std::string> objective_c_preprocessor_definitions;
                                    thekogans_make.GetObjectiveCPreprocessorDefinitions (objective_c_preprocessor_definitions);
                                    for (const auto &objective_c_preprocessor_definition : objective_c_preprocessor_definitions) {
                                        makefileFile << "\\\n  " << objective_c_preprocessor_definition;
                                    }
                                }
                                else if (variable == "objective_c_headers") {
                                    DumpFileLists (
                                        makefileFile,
                                        thekogans_make.objective_c_headers,
                                        thekogans_make,
                                        customBuildList);
                                }
                                else if (variable == "objective_c_sources") {
                                    DumpFileLists (
                                        makefileFile,
                                        thekogans_make.objective_c_sources,
                                        thekogans_make,
                                        customBuildList);
                                }
                                else if (variable == "objective_c_tests") {
                                    DumpFileLists (
                                        makefileFile,
                                        thekogans_make.objective_c_tests,
                                        thekogans_make,
                                        customBuildList);
                                }
                                else if (variable == "objective_cpp_flags") {
                                    std::set<std::string> objective_cpp_flags;
                                    thekogans_make.GetObjectiveCPPFlags (objective_cpp_flags);
                                    for (const auto &objective_cpp_flag : objective_cpp_flags) {
                                        makefileFile << "\\\n  " << objective_cpp_flag;
                                    }
                                }
                                else if (variable == "objective_cpp_preprocessor_definitions") {
                                    std::set<std::string> objective_cpp_preprocessor_definitions;
                                    thekogans_make.GetObjectiveCPPPreprocessorDefinitions (objective_cpp_preprocessor_definitions);
                                    for (const auto &objective_cpp_preprocessor_definition : objective_cpp_preprocessor_definitions) {
                                        makefileFile << "\\\n  " << objective_cpp_preprocessor_definition;
                                    }
                                }
                                else if (variable == "objective_cpp_headers") {
                                    DumpFileLists (
                                        makefileFile,
                                        thekogans_make.objective_cpp_headers,
                                        thekogans_make,
                                        customBuildList);
                                }
                                else if (variable == "objective_cpp_sources") {
                                    DumpFileLists (
                                        makefileFile,
                                        thekogans_make.objective_cpp_sources,
                                        thekogans_make,
                                        customBuildList);
                                }
                                else if (variable == "objective_cpp_tests") {
                                    DumpFileLists (
                                        makefileFile,
                                        thekogans_make.objective_cpp_tests,
                                        thekogans_make,
                                        customBuildList);
                                }
                                else if (variable == "resources") {
                                    DumpFileLists (
                                        makefileFile,
                                        thekogans_make.resources,
                                        thekogans_make,
                                        customBuildList);
                                }
                                else if (variable == "rc_flags") {
                                    std::set<std::string> rc_flags;
                                    thekogans_make.GetRCFlags (rc_flags);
                                    for (const auto &rc_flag : rc_flags) {
                                        makefileFile << "\\\n  " << rc_flag;
                                    }
                                }
                                else if (variable == "rc_preprocessor_definitions") {
                                    std::set<std::string> rc_preprocessor_definitions;
                                    thekogans_make.GetRCPreprocessorDefinitions (rc_preprocessor_definitions);
                                    for (const auto &rc_preprocessor_definition : rc_preprocessor_definitions) {
                                        makefileFile << "\\\n  " << rc_preprocessor_definition;
                                    }
                                }
                                else if (variable == "rc_sources") {
                                    DumpFileLists (
                                        makefileFile,
                                        thekogans_make.rc_sources,
                                        thekogans_make,
                                        customBuildList);
                                }
                                else if (variable == "subsystem") {
                                    makefileFile << thekogans_make.subsystem;
                                }
                                else if (variable == "def_file") {
                                    makefileFile << thekogans_make.def_file;
                                }
                                else if (variable == "custom_build_rules") {
                                    std::list<std::string> extra_clean;
                                    for (auto customBuild : customBuildList) {
                                        for (const auto &output : customBuild->outputs) {
                                            makefileFile << output << " ";
                                        }
                                        makefileFile << ":";
                                        for (const auto &dependency : customBuild->dependencies) {
                                            makefileFile << " " << dependency;
                                        }
                                        std::vector<std::string> recipeLines;
                                        GetLines (customBuild->recipe, recipeLines);
                                        if (!recipeLines.empty ()) {
                                            makefileFile << "\n";
                                            makefileFile <<
                                                "\t$(hide)$(call maybe-mkdir,$(dir $@))\n" <<
                                                "\t$(hide)echo " << (!customBuild->message.empty () ?
                                                    customBuild->message : "Generating $@") << "\n";
                                            makefileFile << "\t$(hide)" << recipeLines[0] << "\n";
                                            for (std::size_t i = 1, count = recipeLines.size (); i < count; ++i) {
                                                makefileFile << "\t";
                                                if (!IsContinuation (recipeLines[i - 1])) {
                                                    makefileFile << "$(hide)";
                                                }
                                                makefileFile << recipeLines[i] << "\n";
                                            }
                                            for (const auto &output : customBuild->outputs) {
                                                extra_clean.push_back (output);
                                            }
                                        }
                                    }
                                    if (!extra_clean.empty ()) {
                                        makefileFile << "\nextra_clean := ";
                                        for (const auto &clean : extra_clean) {
                                            makefileFile << "\\\n  " << clean;
                                        }
                                    }
                                }
                                else {
                                    makefileFile << ch << '(' << variable << ')';
                                }
                            }
                            else {
                                makefileFile << ch;
                            }
                        }
                        return true;
                    }
                    else {
                        THEKOGANS_UTIL_THROW_STRING_EXCEPTION (
                            "Unable to open '%s'.", makefileFilePath.size ());
                    }
                }
                return false;
            }

            void make::Delete (
                    const std::string &project_root,
                    const std::string &config,
                    const std::string &type,
                    bool deleteDependencies) {
                const core::thekogans_make &thekogans_make =
                    core::thekogans_make::GetConfig (
                        project_root,
                        THEKOGANS_MAKE_XML,
                        Type (),
                        config,
                        type);
                if (deleteDependencies) {
                    for (auto dependency : thekogans_make.dependencies) {
                        if (dependency->GetConfigFile () == THEKOGANS_MAKE_XML) {
                            make dependency_ (false);
                            dependency_.Delete (
                                dependency->GetProjectRoot (),
                                dependency->GetConfig (),
                                dependency->GetType (),
                                deleteDependencies);
                        }
                    }
                }
                std::string build_root = core::GetBuildRoot (project_root, Type (), config, type);
                util::Path (ToSystemPath (build_root)).Delete ();
                while (build_root != project_root) {
                    build_root = util::Path (build_root).GetDirectory ();
                    THEKOGANS_UTIL_TRY {
                        util::Path (ToSystemPath (build_root)).Delete (false);
                    }
                    THEKOGANS_UTIL_CATCH_ANY {
                        break;
                    }
                }
            }

        } // namespace generators
    } // namespace make
} // namespace thekogans

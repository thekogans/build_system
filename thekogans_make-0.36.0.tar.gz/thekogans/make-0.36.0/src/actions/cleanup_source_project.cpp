// Copyright 2011 Boris Kogan (boris@thekogans.net)
//
// This file is part of thekogans_make.
//
// thekogans_make is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// thekogans_make is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with thekogans_make. If not, see <http://www.gnu.org/licenses/>.

#include <string>
#include <set>
#include "thekogans/make/core/Source.h"
#include "thekogans/make/Options.h"
#include "thekogans/make/actions/cleanup_source_project.h"

namespace thekogans {
    namespace make {
        namespace actions {

            THEKOGANS_UTIL_IMPLEMENT_DYNAMIC_CREATABLE (cleanup_source_project, Action::TYPE)

            void cleanup_source_project::PrintHelp (std::ostream &stream) const {
                stream <<
                    "-a:" << Type () << " -o:organization -p:project -b:branch\n\n"
                    "a - Remove old versions associated with the given project in "
                    "$SOURCES_ROOT/$organization/Source.xml.\n"
                    "o - Organization name.\n"
                    "p - Project name.\n"
                    "b - Project branch.\n";
            }

            void cleanup_source_project::Execute  () {
                 core::Source source (Options::Instance ()->organization);
                 std::set<std::string> projects;
                 if (!Options::Instance ()->project.empty ()) {
                     projects.insert (Options::Instance ()->project);
                 }
                 else {
                     source.GetProjectNames (projects);
                 }
                 for (const auto &project : projects) {
                     std::set<std::string> branches;
                     if (!Options::Instance ()->branch.empty ()) {
                         branches.insert (Options::Instance ()->branch);
                     }
                     else {
                         source.GetProjectBranches (project, branches);
                     }
                     for (const auto &branch : branches) {
                         source.CleanupProject (project, branch);
                     }
                 }
                 source.Save ();
             }

        } // namespace actions
    } // namespace make
} // namespace thekogans

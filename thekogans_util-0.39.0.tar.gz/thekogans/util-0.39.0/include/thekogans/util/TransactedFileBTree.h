// Copyright 2011 Boris Kogan (boris@thekogans.net)
//
// This file is part of libthekogans_util.
//
// libthekogans_util is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// libthekogans_util is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with libthekogans_util. If not, see <http://www.gnu.org/licenses/>.

#if !defined (__thekogans_util_TransactedFileBTree_h)
#define __thekogans_util_TransactedFileBTree_h

#include <string>
#include <vector>
#include "thekogans/util/Config.h"
#include "thekogans/util/Types.h"
#include "thekogans/util/Serializable.h"
#include "thekogans/util/Serializer.h"
#include "thekogans/util/BlockAllocator.h"
#include "thekogans/util/TransactedFile.h"

namespace thekogans {
    namespace util {

        /// \struct TransactedFileBTree TransactedFileBTree.h thekogans/util/TransactedFileBTree.h
        ///
        /// \brief
        /// A TransactedFileBTree is a \see{TransactedFile::Object}. It's an ordered, associative
        /// container capable of storing practically any key/value type. It's attributes are that
        /// all searches, insertions and deletions take O(H) where H is the height of the tree.
        /// These are TransactedFileBTree's bigest strengths. One of it's biggest weaknesses is
        /// the fact that iterators don't survive modifications (Insert/Remove). This is why I
        /// provide a forward iterator only. Use it to step through a range of nodes collecting
        /// their data. See an example provided with \see{TransactedFileBTree::Iterator}.
        /// TransactedFileBTree uses the full power of \see{DynamicCreatable} and \see{Serializable}
        /// for it's key and value. That means that key can be practically any random size object
        /// (as long as it derives from \see{TransactedFileBTree::Key} and implements the interface).
        /// And value can be any \see{Serializable} derived type.
        struct _LIB_THEKOGANS_UTIL_DECL TransactedFileBTree : public TransactedFile::Object {
            /// \brief
            /// Declare \see{RefCounted} pointers.
            THEKOGANS_UTIL_DECLARE_REF_COUNTED_POINTERS (TransactedFileBTree)

            /// \struct TransactedFileBTree::Key TransactedFileBTree.h thekogans/util/TransactedFileBTree.h
            ///
            /// \brief
            /// Key adds order to the \see{Serializable}.
            struct _LIB_THEKOGANS_UTIL_DECL Key : public Serializable {
                /// \brief
                /// Key is a \see{util::DynamicCreatable} abstract base.
                THEKOGANS_UTIL_DECLARE_DYNAMIC_CREATABLE_ABSTRACT_BASE (Key)

            #if defined (THEKOGANS_UTIL_TYPE_Static)
                /// \brief
                /// Because Key uses dynamic initialization, when using
                /// it in static builds call this method to have the Key
                /// explicitly include all internal key types. Without
                /// calling this api, the only keys that will be available
                /// to your application are the ones you explicitly link to.
                static void StaticInit ();
            #endif // defined (THEKOGANS_UTIL_TYPE_Static)

                /// \brief
                /// Used to find keys with matching prefixs.
                /// NOTE: This represents the prefix.
                /// \param[in] key Key whose prefix to compare against.
                /// \return -1 == this is < key, 0 == this == key, 1 == this is greater than key.
                virtual i32 PrefixCompare (const Key &key) const = 0;
                /// \brief
                /// Used to order keys.
                /// \param[in] key Key to compare against.
                /// \return -1 == this is < key, 0 == this == key, 1 == this is greater than key.
                virtual i32 Compare (const Key &key) const = 0;
                /// \brief
                /// This method is used by Compare and PrefixCompare to
                /// treat all key types as strings.
                /// \return String representation of the key.
                /// NOTE: The return type is a string reference. That means
                /// you cannot create a string on the stack and return it as
                /// that would result in a dangling pointer. If your key
                /// type is other than string you should convert it to
                /// string in the ctor and use it as a return value. This
                /// design has two advantages; 1. Conversion is done once and
                /// 2. Returning a const reference negates the need for object copying.
                virtual const std::string &ToString () const = 0;
            };

        protected:
            /// \brief
            /// Forward declaration of \see{Node} needed by \see{Iterator}.
            struct Node;

        public:
            /// \struct TransactedFileBTree::Iterator TransactedFileBTree.h thekogans/util/TransactedFileBTree.h
            ///
            /// \brief
            /// Iterator implements a forward cursor over a range of btree entries.
            /// Call \see{FindFirst} below with a reference to an iterator and then
            /// use it to move forward through the range of entries. The range can either
            /// be based on a prefix or the entire tree. Since Iterator is unidirectional
            /// (forward only), there's no backing up (the code complexity is just not
            /// worth the added benefit). You get one shot through the range. This
            /// design also means that you cannot know, a priori, how many entries
            /// are in the range. You need to step through it to count them up.
            /// WARNING: \see{FindFirst} will return a live iterator pointing in to the
            /// actual data in the btree (not a copy). The nature of TransactedFileBTrees is such that
            /// almost any modification to its structure invalidates iterators currently
            /// in existance. This means that you CAN'T (or at least shouldn't) write
            /// code like this:
            ///
            /// Deleting a range of nodes:
            ///
            /// Ex:
            ///
            /// \code{.cpp}
            /// // WARNING: This is wrong! DON'T do this. It can lead
            /// // to very hard to track down crashes as the posibility
            /// // of a crash is completely dependent on the state of
            /// // the TransactedFileBTree.
            /// Iterator it (some prefix);
            /// for (btree.FindFirst (it); !it.IsFinished (); it.Next ()) {
            ///     btree.Remove (*it.GetKey ());
            /// }
            /// \endcode
            ///
            /// Instead you must write it like this:
            ///
            /// Ex:
            ///
            /// \code{.cpp}
            /// // This is the right way.
            /// std::vector<Key::SharedPtr> keys;
            /// Iterator it (some prefix);
            /// for (btree.FindFirst (it); !it.IsFinished (); it.Next ()) {
            ///     keys.push_back (it.GetKey ());
            /// }
            /// for (std::size_t i = 0, count = keys.size (); i < count; ++i) {
            ///     btree.Remove (*keys[i]);
            /// }
            /// \endcode
            struct _LIB_THEKOGANS_UTIL_DECL Iterator {
            protected:
                /// \brief
                /// Prefix to iterate over (nullptr == entire tree).
                Key::SharedPtr prefix;
                /// \brief
                /// Alias for std::pair<Node *, ui32>.
                using NodeIndex = std::pair<Node *, ui32>;
                /// \brief
                /// Stack of parents allowing us to navigate the tree.
                /// The nodes store no parent pointers. They would be
                /// a nightmare to maintain.
                std::vector<NodeIndex> parents;
                /// \brief
                /// Current node we're iterating over.
                NodeIndex node;
                /// \brief
                /// Flag indicating the iterator is done and will not
                /// return true from Next again. It is only set in \see{TransactedFileBTree::FindFirst}
                /// and \see{Next} below and only after it made sure that it properly
                /// initialized the iterator.
                bool finished;

            public:
                /// \brief
                /// ctor.
                /// \param[in] prefix_ Prefix to iterate over (nullptr == entire tree).
                Iterator (Key::SharedPtr prefix_ = nullptr) :
                    prefix (prefix_),
                    node (nullptr, 0),
                    finished (true) {}

                /// \brief
                /// Return true if the iterator is finished.
                /// \return true == the iterator is finished.
                inline bool IsFinished () const {
                    return finished;
                }

                /// \brief
                /// Step to the next entry in the range.
                /// \return true == Iterator is now pointing at the next entry.
                /// Use GetKey and GetValue to examine it's contents.
                /// false == the iterator is finished through the range or the
                /// range was empty to begin with.
                bool Next ();

                /// \brief
                /// If we're not finished, return the key associated with the current entry.
                /// \return Key associated with the current entry.
                Key::SharedPtr GetKey () const;
                /// \brief
                /// If we're not finished, return the value associated with the current entry.
                /// \return Value associated with the current entry.
                Serializable::SharedPtr GetValue () const;
                /// \brief
                /// If we're not finished, set the value associated with the current entry.
                /// \param[in] value New \see{Value} to associate with the current entry.
                void SetValue (Serializable::SharedPtr value);

            private:
                /// \brief
                /// Clear the internal state and reset the iterator.
                /// Used by \see{TransactedFileBTree} to manage passed in iterators.
                void Clear ();
                /// \brief
                /// Reset the iterator to the given \see{Node::Entry}.
                /// Used by \see{TransactedFileBTree} to manage passed in iterators.
                /// \param[in] node_ \see{Node}.
                /// \param[in] index Node entry index.
                void Reset (
                    Node *node_,
                    ui32 index);

                /// \brief
                /// TransactedFileBTree is the only one trusted to access sensitive protected data.
                friend struct TransactedFileBTree;
            };

        protected:
            /// \struct TransactedFileBTree::Header TransactedFileBTree.h thekogans/util/TransactedFileBTree.h
            ///
            /// \brief
            /// Header contains global btree info.
            struct Header {
                /// \brief
                /// Key type.
                SerializableHeader keyContext;
                /// \brief
                /// Value type.
                SerializableHeader valueContext;
                /// \brief
                /// Values can be stored as a single array or as first class objects
                /// (\see{TransactedFile::SerializableObject}) in their own right.
                static const ui32 FLAGS_VALUE_AS_OBJECT = 1;
                /// \brief
                /// Combination of the above flags.
                Flags32 flags;
                /// \brief
                /// Entries per node.
                /// NOTE: Its type is ui32 because 1. we want something
                /// fixed size and 2. if you need more than 4G enries in
                /// one node, you don't need a btree. You need something else.
                ui32 entriesPerNode;
                /// \brief
                /// Root node offset.
                TransactedFile::Allocator::PtrType rootOffset;

                /// \brief
                /// ctor.
                /// \param[in] keyContext_ \see{DynamicCreatable} type.
                /// \param[in] valueContext_ \see{DynamicCreatable} type.
                /// \param[in] entriesPerNode_ Entries per node.
                Header (
                    const SerializableHeader &keyContext_ = SerializableHeader (),
                    const SerializableHeader &valueContext_ = SerializableHeader (),
                    ui32 flags_ = 0,
                    ui32 entriesPerNode_ = DEFAULT_ENTRIES_PER_NODE) :
                    keyContext (keyContext_),
                    valueContext (valueContext_),
                    flags (flags_),
                    entriesPerNode (entriesPerNode_),
                    rootOffset (0) {}

                /// \brief
                /// Return true if values are stored as objects (\see{TransactedFile::SerializableObject}).
                /// \return true == values are stored as objects (\see{TransactedFile::SerializableObject}).
                inline bool IsValueAsObject () const {
                    return flags.Test (FLAGS_VALUE_AS_OBJECT);
                }

                /// \brief
                /// Return the serialized size of the header.
                inline std::size_t Size () const {
                    return
                        UI32_SIZE + // magic
                        keyContext.Size (true) +
                        valueContext.Size (true) +
                        Serializer::Size (flags) +
                        Serializer::Size (entriesPerNode) +
                        Serializer::Size (rootOffset);
                }
            } header;
            /// \brief
            /// Key and Value types are cast in stone (in the ctor).
            /// Since we're going to be creating a lot of keys and values
            /// (every \see{Node::Entry} of every \see{Node}), we can save
            /// a ton on \see{DynamicCreatable::CreateType} by caching their
            /// factories and calling them directly when needed.
            DynamicCreatable::FactoryType keyFactory;
            /// \brief
            /// See comment for keyFactory.
            DynamicCreatable::FactoryType valueFactory;
            /// \brief
            /// An instance of \see{BlockAllocator} to allocate \see{Node}s.
            BlockAllocator::SharedPtr nodeAllocator;
            /// \struct TransactedFileBTree::Node TransactedFileBTree.h thekogans/util/TransactedFileBTree.h
            ///
            /// \brief
            /// TransactedFileBTree nodes store sorted key/value pairs and pointers to children nodes.
            struct Node : public TransactedFile::Object {
                /// \brief
                /// Declare \see{RefCounted} pointers.
                THEKOGANS_UTIL_DECLARE_REF_COUNTED_POINTERS (Node)

                /// \brief
                /// TransactedFileBTree to which this node belongs.
                TransactedFileBTree &btree;
                /// \brief
                /// Count of entries.
                ui32 count;
                /// \brief
                /// Left most child node block offset.
                TransactedFile::Allocator::PtrType leftOffset;
                /// \brief
                /// Left most child node.
                Node *left;
                /// \brief
                /// Key/value array offset.
                TransactedFile::Allocator::PtrType keyValueOffset;
                /// \struct TransactedFileBTree::Node::Entry TransactedFileBTree.h thekogans/util/TransactedFileBTree.h
                ///
                /// \brief
                /// Node entries contain keys, values and right (grater then) children.
                struct Entry {
                    /// \brief
                    /// Entry key.
                    Key *key;
                    /// \brief
                    /// Value block offset.
                    TransactedFile::Allocator::PtrType valueOffset;
                    /// \brief
                    /// \see{TransactedFile::SerializableObject} encapsulating the value.
                    TransactedFile::SerializableObject *value;
                    /// \brief
                    /// Right child node block offset.
                    TransactedFile::Allocator::PtrType rightOffset;
                    /// \brief
                    /// Right child node.
                    Node *right;

                    /// \brief
                    /// ctor.
                    /// NOTE: Because of the way we allocate Node this ctor
                    /// is here for show. It will never be called as we're
                    /// treating Entry as POT. It actually gets initialized
                    /// in the operator >>.
                    /// \param[in] key_ Entry key.
                    /// \param[in] value_ Entry value.
                    Entry (
                        Key *key_ = nullptr,
                        TransactedFile::SerializableObject *value_ = nullptr) :
                        key (key_),
                        valueOffset (0),
                        value (value_),
                        rightOffset (0),
                        right (nullptr) {}

                    /// \brief
                    /// Entry size on disk.
                    static const std::size_t SIZE_WITH_VALUE =
                        TransactedFile::Allocator::PTR_TYPE_SIZE + // valueOffset;
                        TransactedFile::Allocator::PTR_TYPE_SIZE;  // rightOffset;

                    /// \brief
                    /// Entry size on disk.
                    static const std::size_t SIZE_WITHOUT_VALUE =
                        TransactedFile::Allocator::PTR_TYPE_SIZE; // rightOffset;
                };
                /// \brief
                /// Entry array. Allocated when the node is allocated.
                Entry *entries;

                /// \brief
                /// ctor.
                /// \param[in] btree_ TransactedFileBTree to which this node belongs.
                /// \param[in] offset Node offset on disk.
                Node (
                    TransactedFileBTree &btree_,
                    TransactedFile::Allocator::PtrType offset = 0);
                /// \brief
                /// dtor.
                virtual ~Node ();

                /// \brief
                /// Given the number of entries, return the node size in bytes.
                /// \param[in] entriesPerNode Entries per node.
                /// \return Size of node in memory.
                static std::size_t Size (std::size_t entriesPerNode);
                /// \brief
                /// Allocate a node.
                /// \param[in] btree TransactedFileBTree to which this node belongs.
                /// \param[in] offset Node offset on disk.
                static Node *Alloc (
                    TransactedFileBTree &btree,
                    TransactedFile::Allocator::PtrType offset = 0);
                /// \brief
                /// Delete the node and it's sub-tree.
                /// \param[in] fileAllocator Btree heap.
                /// \param[in] offset Node offset.
                static void FreeSubtree (
                    TransactedFileBTree &btree,
                    TransactedFile::Allocator::PtrType offset);

                /// \brief
                /// Return key at entry index.
                /// \return \see{Key} at entry index.
                Key::SharedPtr GetKey (ui32 index);
                /// \brief
                /// Return value at entry index.
                /// \return Value at entry index.
                Serializable::SharedPtr GetValue (ui32 index);
                /// \brief
                /// Set value at the given \see{Entry} index.
                /// \param[in] index \see{Entry} index to set the new value at.
                /// \param[in] value New \see{Value} to set.
                void SetValue (
                    ui32 index,
                    Serializable::SharedPtr value);
                /// \brief
                /// Return the left child of an entry at the given index.
                /// NOTE: If you need the very last (right) child, call
                /// GetChild (node->count). If you find yourself with an entry
                /// index and you need its right child, call GetChild (index + 1).
                /// \param[in] index Index of entry whose left child to retrieve
                /// (0 == left, !0 == entries[index - 1].right).
                /// \return Left child node at the given index. nullptr if no child
                /// at that index exists.
                Node *GetChild (ui32 index);
                /// \brief
                /// Just like Find but begins at whatever the index was set to at call
                /// time. You should never need to call this method directly. The driver
                /// which starts the whole process is FindFirstPrefix and it will do the
                /// right thing. But if you ever find yourself callling this method directly
                /// don't forget to initialize index prior to call.
                /// \param[in] prefix Prefix to find.
                /// \param[in,out] index On entry contains the last index of entry
                /// to search. On successful return will contain the index of the matching
                /// entry.
                /// \return true == found the prefix.
                bool PrefixFind (
                    const Key &prefix,
                    ui32 &index) const;
                /// \brief
                /// Used by \see{TransactedFileBTree::FindFirst} to locate the start of the prefix.
                /// Due to the nature of binary search, \see{PrefixFind} can return
                /// true with a prefix found in the middle of the range. This method
                /// keeps reducing the search space (using \see{PrefixFind}) to locate
                /// the start of the range.
                /// \param[in] prefix Prefix to find.
                /// \param[out] index On true return, contains the index of the first
                /// entry in the node that matches the given prefix.
                /// \return true == found the prefix and it's the first occurence.
                bool FindFirstPrefix (
                    const Key &prefix,
                    ui32 &index) const;
                /// \brief
                /// Search for a given key.
                /// \param[in] key \see{Key} to search for.
                /// \param[out] index If found will contain the index of the key.
                /// If not found will contain the index of the closest larger key.
                /// \return true == found the key.
                bool Find (
                    const Key &key,
                    ui32 &index) const;
                /// \enum
                /// Insert return codes.
                enum InsertResult {
                    /// \brief
                    /// Entry was inserted.
                    Inserted,
                    /// \brief
                    /// Entry is a duplicate.
                    Duplicate,
                    /// \brief
                    /// Node is full.
                    Overflow
                };
                /// \brief
                /// Try to recursively insert the given entry.
                /// \param[in] entry \see{Entry} to insert.
                /// \param[out] it Iterator to update with the inserted entry.
                /// \return true == entry inserted. false == the entire sub-tree
                /// rooted at this node is full. Time to split the node.
                InsertResult Insert (
                    Entry &entry,
                    Iterator &it);
                /// \brief
                /// Try to recursively delete the given key.
                /// \param[in] key \see{Key} whose entry we want to delete.
                /// \return true == entry was deleted. false == key not found.
                bool Remove (const Key &key);
                /// \brief
                /// The algorithm checks the left and right children @index for
                /// conformity and performs necessary adjustments to maintain the
                /// TransactedFileBTree structure. If one of the children is poor an entry is
                /// rotated in to it from the other child. If they are both poor,
                /// the algorithm merges the two children in to one.
                /// \param[in] index Index of entry whos left and right child to check.
                void RestoreBalance (ui32 index);
                /// \brief
                /// Called by RestoreBalance to rotate an \see{Entry} from left
                /// child to right child.
                /// \param[in] index Index of \see{Entry}.
                /// \param[in] left Left child.
                /// \param[in] right Right child.
                void RotateRight (
                    ui32 index,
                    Node *left,
                    Node *right);
                /// \brief
                /// Called by RestoreBalance to rotate an \see{Entry} from right
                /// child to left child.
                /// \param[in] index Index of \see{Entry}.
                /// \param[in] left Left child.
                /// \param[in] right Right child.
                void RotateLeft (
                    ui32 index,
                    Node *left,
                    Node *right);
                /// \brief
                /// Called by RestoreBalance to merge two poor nodes in to one.
                /// \param[in] index Index of the \see{Entry} whos left
                /// and right children to merge.
                /// \param[in] left \see{Entry} left child.
                /// \param[in] right \see{Entry} right child.
                /// NOTE: The algorithm merges the entries from right
                /// together with entry @index in to the left child.
                /// Right is deleted after.
                void Merge (
                    ui32 index,
                    Node *left,
                    Node *right);
                /// \brief
                /// Split the full node in the middle
                /// (splitIndex = btree.header.entriesPerNode / 2).
                /// \param[out] node Node that will receive entries >= splitIndex.
                void Split (Node *node);
                /// \brief
                /// Add the given node's entries to this one. The empty node
                /// is deleted after.
                /// \param[in] node Node whose entries are to be added.
                void Concatenate (Node *node);
                /// \brief
                /// Add the given \see{Entry} to the end of the list.
                /// \param[in] entry \see{Entry} to add.
                inline void Concatenate (const Entry &entry) {
                    InsertEntry (entry, count);
                }
                /// \brief
                /// Insert the given entry at the given index.
                /// \param[in] entry \see{Entry} to insert.
                /// \param[in] index Index to insert at.
                void InsertEntry (
                    const Entry &entry,
                    ui32 index);
                /// \brief
                /// Remove the entry at the given index.
                /// \param[in] index Index of entry to remove.
                void RemoveEntry (ui32 index);
                /// \brief
                /// Return true if the node is empty.
                /// \return true == node is empty.
                inline bool IsEmpty () const {
                    return count == 0;
                }
                /// \brief
                /// Return true if the node is full.
                /// \return true == node is full.
                inline bool IsFull () const {
                    return count == btree.header.entriesPerNode;
                }
                /// \brief
                /// Return true if less than half the nodes entries are occupied.
                /// \return true if less than half the nodes entries are occupied.
                inline bool IsPoor () const {
                    return count < btree.header.entriesPerNode / 2;
                }
                /// \brief
                /// Return true if more than half the nodes entries are occupied.
                /// \return true if more than half the nodes entries are occupied.
                inline bool IsPlentiful () const {
                    return count > btree.header.entriesPerNode / 2;
                }

            protected:
                /// \brief
                /// Clear the cache.
                void Reset ();

                // RefCounted
                /// \brief
                /// Undo what Alloc does.
                virtual void Harakiri () override;

                // TransactedFile::Object
                /// \brief
                /// We need to free keyValueOffset.
                virtual void Free () override;
                /// \brief
                /// Node is fixed size.
                /// \return true.
                virtual bool IsFixedSize () const override {
                    return true;
                }
                /// \brief
                /// Return the node size on disk.
                /// \return Node size.
                virtual std::size_t Size () const noexcept override {
                    return
                        UI32_SIZE + // magic
                        UI32_SIZE + // count
                        TransactedFile::Allocator::PTR_TYPE_SIZE + // leftOffset
                        TransactedFile::Allocator::PTR_TYPE_SIZE + // keyValueOffset
                        btree.header.entriesPerNode *
                            (btree.header.IsValueAsObject () ?
                                Entry::SIZE_WITH_VALUE :
                                Entry::SIZE_WITHOUT_VALUE); // entries
                }
                /// \brief
                /// Read the node from the given serializer.
                /// \param[in] serializer \see{Serializer} to read the node from.
                virtual void Read (Serializer &serializer) override;
                /// \brief
                /// Write the node to the given serializer.
                /// \param[in] serializer \see{Serializer} to write the node to.
                virtual void Write (Serializer &serializer) override;

                /// \brief
                /// Needs access to Free.
                friend struct TransactedFileBTree;
            } *root;

        public:
            /// \brief
            /// Default number of entries per node.
            /// NOTE: This is a tunable parameter that should be used
            /// during system integration to provide the best performance
            /// for your needs. Once the heap is created though, this
            /// value is set in stone and the only way to change it is
            /// to delete the file and try again.
            static const std::size_t DEFAULT_ENTRIES_PER_NODE = 256;

            /// \brief
            /// ctor.
            /// \param[in] file \see{TransactedFile} where the btree resides.
            /// \param[in] offset Heap offset of the \see{Header} block.
            /// \param[in] keyContext \see{DynamicCreatable} key type.
            /// \param[in] valueContext \see{DynamicCreatable} value type. If empty,
            /// will store any type derived from \see{Serializable}.
            /// \param[in] valueAsObject true == Values are stored as seperate objects
            /// (\see{TransactedFile::SerializableObject}). false == objects are stored
            /// in one contiguous array.
            /// \param[in] entriesPerNode If we're creating the btree, contains entries per
            /// \see{Node}. If we're reading an existing btree, this value will come from the
            /// \see{Header}.
            /// \param[in] nodesPerPage \see{Node}s are allocated using a \see{BlockAllocator}.
            /// This value sets the number of nodes that will fit on it's page. It's a subtle
            /// tunning parameter that might result in slight performance gains (depending on
            /// your situation). For the most part leaving it alone is the most sensible thing
            /// to do.
            /// \param[in] allocator This is the \see{Allocator} used to allocate pages
            /// for the \see{BlockAllocator}. As with the previous parameter, the same
            /// advice aplies.
            /// PRO TIP: If you're interested in creating 'secure' TransactedFileBTrees, pass
            /// \see{thekogans::util::SecureAllocator}::Instance () for allocator.
            /// Keep in mind, secure pages are a scarce resource and should NOT be
            /// used like main application memory. But for small enough trees
            /// containing sensitive data like keys or other personal info, they
            /// might be just the ticket. You will probably need to call;
            /// \see{thekogans::util::SecureAllocator::ReservePages}.
            TransactedFileBTree (
                TransactedFile::SharedPtr file,
                TransactedFile::Allocator::PtrType offset,
                const SerializableHeader &keyContext = SerializableHeader (),
                const SerializableHeader &valueContext = SerializableHeader (),
                bool valueAsObject = false,
                std::size_t entriesPerNode = DEFAULT_ENTRIES_PER_NODE,
                std::size_t nodesPerPage = BlockAllocator::DEFAULT_BLOCKS_PER_PAGE,
                util::Allocator::SharedPtr allocator = DefaultAllocator::Instance ());
            /// \brief
            /// dtor.
            virtual ~TransactedFileBTree ();

            /// \brief
            /// Search for the given key in the btree.
            /// \param[in] key \see{Key} to search for.
            /// \param[out] it If found the iterator will point to the entry.
            /// \return true == found.
            bool Find (
                const Key &key,
                Iterator &it);
            /// \brief
            /// Insert the given key in to the btree.
            /// \param[in] key Key to insert.
            /// \param[in] value Value associated with the given key.
            /// \param[out] it If inserted, will point at the node entry.
            /// \return true == added. false == duplicate. If false, return
            /// the current entry in it.
            bool Insert (
                Key::SharedPtr key,
                Serializable::SharedPtr value,
                Iterator &it);
            /// \brief
            /// Delete the given key from the btree.
            /// \param[in] key Key to delete.
            /// \return true == entry deleted. false == entry not found.
            bool Remove (const Key &key);

            /// \brief
            /// Reset the iterator to point to the first occurence of it.prefix.
            /// If the prefix is a nullptr, point to the smallest entry (smallest
            /// as returned by \see{Key::Compare}, which could actually be the largest
            /// if the tree is in descending  order).
            /// IMPORTANT: It's practically imposible to deduce that an iterator
            /// has been invalidated by Insert/Delete. To maintain the btree structure
            /// the rotations and merges may delete some nodes while moving others.
            /// It is therefore important that any iterator be created, used quickly,
            /// and discarded.
            /// \param[in,out] it Iterator to reset.
            /// \return true == The iterator is pointing to the first occurance of
            /// it.prefix (or smallest element if it.prefix == nullptr). false == the
            /// iterator is empty.
            bool FindFirst (Iterator &it);

            // TransactedFile::TransactionParticipant
            /// \brief
            /// We have a pointer to root we need to dispose of.
            virtual void Free () override;

        protected:
            // TransactedFile::Object
            /// \brief
            /// \see{Header} is fixed size.
            /// \return true.
            virtual bool IsFixedSize () const override {
                return true;
            }
            /// \brief
            /// Return the \see{Header} size.
            /// \return \see{Header} size.
            virtual std::size_t Size () const noexcept override {
                return header.Size ();
            }
            /// \brief
            /// Read the \see{Header} from the given serializer.
            /// \param[in] serializer \see{Serializer} to read the \see{Header} from.
            virtual void Read (Serializer &serializer) override;
            /// \brief
            /// Write the \see{Header} to the given serializer.
            /// \param[out] serializer \see{Serializer} to write the \see{Header} to.
            virtual void Write (Serializer &serializer) override;

            /// \brief
            /// Needs access to private members.
            friend Serializer &operator << (
                Serializer &serializer,
                const Header &header);
            /// \brief
            /// Needs access to private members.
            friend Serializer &operator >> (
                Serializer &serializer,
                Header &header);

            /// \brief
            /// TransactedFileBTree is neither copy constructable, nor assignable.
            THEKOGANS_UTIL_DISALLOW_COPY_AND_ASSIGN (TransactedFileBTree)
        };

        /// \brief
        /// Implement TransactedFileBTree::Key extraction operators.
        THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_EXTRACTION_OPERATORS (TransactedFileBTree::Key)

    } // namespace util
} // namespace thekogans

#endif // !defined (__thekogans_util_TransactedFileBTree_h)

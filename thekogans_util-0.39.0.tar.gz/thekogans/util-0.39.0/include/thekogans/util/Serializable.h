// Copyright 2016 Boris Kogan (boris@thekogans.net)
//
// This file is part of libthekogans_util.
//
// libthekogans_util is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// libthekogans_util is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with libthekogans_util. If not, see <http://www.gnu.org/licenses/>.

#if !defined (__thekogans_util_Serializable_h)
#define __thekogans_util_Serializable_h

#include <cstddef>
#include <string>
#include <ostream>
#include "pugixml/pugixml.hpp"
#include "thekogans/util/Config.h"
#include "thekogans/util/Types.h"
#include "thekogans/util/Flags.h"
#include "thekogans/util/Constants.h"
#include "thekogans/util/DynamicCreatable.h"
#include "thekogans/util/SerializableHeader.h"
#include "thekogans/util/Serializer.h"
#include "thekogans/util/JSON.h"
#include "thekogans/util/Buffer.h"
#include "thekogans/util/StringUtils.h"
#include "thekogans/util/ValueParser.h"

namespace thekogans {
    namespace util {

        /// \struct Serializable Serializable.h thekogans/util/Serializable.h
        ///
        /// \brief
        /// Serializable extends \see{DynamicCreatable} to provide object storage/retrieval
        /// facilities for three distinct protocols; binary, XML and JSON. It is an abstract
        /// base for all supported serializable types and exposes machinery used by descendants
        /// to register themselves for dynamic discovery, creation and serializable insertion and
        /// extraction. (For a good real world example have a look at \see{crypto::Serializable}
        /// and it's derivatives.)
        struct _LIB_THEKOGANS_UTIL_DECL Serializable : public DynamicCreatable {
            /// \brief
            /// Serializable is a \see{DynamicCreatable} abstract base.
            THEKOGANS_UTIL_DECLARE_DYNAMIC_CREATABLE_ABSTRACT_BASE (Serializable)

        #if defined (THEKOGANS_UTIL_TYPE_Static)
            /// \brief
            /// Register all known bases. This method is meant to be added
            /// to as new Serializable derivatives are added to the system.
            static void StaticInit ();
        #endif // defined (THEKOGANS_UTIL_TYPE_Static)

            /// \brief
            /// Given a context, return the header needed to insert this
            /// serializable in to a \see{Serializer}.
            /// \param[in] context Partially filled in \see{SerializableHeader}.
            /// \return \see{SerializableHeader} containing the missing context pieces.
            SerializableHeader GetHeader (
                const SerializableHeader &context = SerializableHeader ()) const noexcept;
            /// \brief
            /// Return the binary size of the serializable including the header.
            /// \param[in] context Partially filled in \see{SerializableHeader}.
            /// \return Size of the binary serializable including the header.
            std::size_t GetSize (
                const SerializableHeader &context = SerializableHeader ()) const noexcept;

            /// \brief
            /// Return the serializable version.
            /// \return Serializable version.
            virtual ui16 Version () const noexcept = 0;
            /// \brief
            /// Return the serializable class size.
            /// If CLASS_SIZE != 0, this serializable is fixed size.
            /// If CLASS_SIZE == 0, this serializable is variable size
            /// and you need to call Size to get the size of this instance.
            /// \return Serializable class size.
            virtual std::size_t ClassSize () const noexcept = 0;

            /// \brief
            /// Return the serializable instance size (excluding the header).
            /// \return Serializable instance size.
            virtual std::size_t Size () const noexcept {
                return ClassSize ();
            }
            /// \brief
            /// Read the serializable from the given serializer.
            /// \param[in] header \see{SerializableHeader} governing the stored data.
            /// \param[in] serializer Serializer to read the serializable from.
            virtual void Read (
                const SerializableHeader & /*header*/,
                Serializer & /*serializer*/) = 0;
            /// \brief
            /// Write the serializable to the given serializer.
            /// IMPORTANT: You must use the \see{Serializer::context} to determine
            /// the version and the amount of space you have to write.
            /// \param[out] serializer Serializer to write the serializable to.
            virtual void Write (Serializer & /*serializer*/) const = 0;

            /// \brief
            /// Return the serializable XML size.
            /// \return Serializable XML size.
            virtual std::size_t SizeXML () const noexcept {
                assert (0);
                return 0;
            }
            /// \brief
            /// Read the Serializable from an XML DOM.
            /// \param[in] node XML DOM representation of a Serializable.
            virtual void ReadXML (
                    const SerializableHeader & /*header*/,
                    const pugi::xml_node & /*node*/) {
                assert (0);
                THEKOGANS_UTIL_THROW_STRING_EXCEPTION (
                    "ReadXML is unimplemented for: %s.", Type ());
            }
            /// \brief
            /// Write the Serializable to the XML DOM.
            /// \param[out] node Parent node.
            virtual void WriteXML (pugi::xml_node & /*node*/) const {
                assert (0);
                THEKOGANS_UTIL_THROW_STRING_EXCEPTION (
                    "WriteXML is unimplemented for: %s.", Type ());
            }

            /// \brief
            /// Return the serializable JSON size.
            /// \return Serializable JSON size.
            virtual std::size_t SizeJSON () const noexcept {
                assert (0);
                return 0;
            }
            /// \brief
            /// Read the Serializable from an JSON DOM.
            /// \param[in] node JSON DOM representation of a Serializable.
            virtual void ReadJSON (
                    const SerializableHeader & /*header*/,
                    const JSON::Object & /*object*/) {
                assert (0);
                THEKOGANS_UTIL_THROW_STRING_EXCEPTION (
                    "ReadJSON is unimplemented for: %s.", Type ());
            }
            /// \brief
            /// Write a Serializable to the JSON DOM.
            /// \param[out] node Parent node.
            virtual void WriteJSON (JSON::Object & /*object*/) const {
                assert (0);
                THEKOGANS_UTIL_THROW_STRING_EXCEPTION (
                    "WriteJSON is unimplemented for: %s.", Type ());
            }
        };

        /// \def THEKOGANS_UTIL_DECLARE_SERIALIZABLE_VERSION(_T)
        /// Common defines for Serializable.
        #define THEKOGANS_UTIL_DECLARE_SERIALIZABLE_VERSION(_T)\
        public:\
            static const thekogans::util::ui16 VERSION;

        /// \def THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_VERSION(_T, version)
        /// Serializable overrides.
        #define THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_VERSION(_T, version)\
            const thekogans::util::ui16 _T::VERSION = version;

        /// \def THEKOGANS_UTIL_DECLARE_SERIALIZABLE_Version(_T)
        /// Common defines for Serializable.
        #define THEKOGANS_UTIL_DECLARE_SERIALIZABLE_Version(_T)\
        public:\
            virtual thekogans::util::ui16 Version () const noexcept override;

        /// \def THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_Version(_T)
        /// Serializable overrides.
        #define THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_Version(_T)\
            thekogans::util::ui16 _T::Version () const noexcept {\
                return VERSION;\
            }

        /// \def THEKOGANS_UTIL_DECLARE_SERIALIZABLE_CLASS_SIZE(_T)
        /// Declare the \see{Serializable} class size. If class
        /// size is != 0 that means that the class is fixed size.
        /// Every instance is this size. If it's == 0 that means
        /// the class is variable size and every instance will
        /// need to be queried (Size) individually to get its size.
        #define THEKOGANS_UTIL_DECLARE_SERIALIZABLE_CLASS_SIZE(_T)\
        public:\
            static const std::size_t CLASS_SIZE;

        /// \def THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_CLASS_SIZE(_T, classSize)
        /// Implement the \see{Serializable} class size.
        #define THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_CLASS_SIZE(_T, classSize)\
            const std::size_t _T::CLASS_SIZE = classSize;

        /// \def THEKOGANS_UTIL_DECLARE_SERIALIZABLE_ClassSize(_T)
        /// Declare the \see{Serializable} class size getter.
        #define THEKOGANS_UTIL_DECLARE_SERIALIZABLE_ClassSize(_T)\
        public:\
            virtual std::size_t ClassSize () const noexcept override;

        /// \def THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_ClassSize(_T)
        /// Implement the \see{Serializable} class size getter.
        #define THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_ClassSize(_T)\
            std::size_t _T::ClassSize () const noexcept {\
                return CLASS_SIZE;\
            }

        /// \def THEKOGANS_UTIL_DECLARE_SERIALIZABLE_GetContext(_T)
        /// Declare the \see{Serializable} GetContext method.
        #define THEKOGANS_UTIL_DECLARE_SERIALIZABLE_GetContext(_T)\
        public:\
            static thekogans::util::SerializableHeader GetContext ();

        /// \def THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_GetContext(_T)
        /// Implement the \see{Serializable} GetContext method.
        #define THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_GetContext(_T)\
            thekogans::util::SerializableHeader _T::GetContext () {\
                return thekogans::util::SerializableHeader (\
                    _T::TYPE, _T::VERSION, _T::CLASS_SIZE);\
            }

        /// \def THEKOGANS_UTIL_DECLARE_SERIALIZABLE_OVERRIDE(_T)
        /// Common defines for Serializable.
        #define THEKOGANS_UTIL_DECLARE_SERIALIZABLE_OVERRIDE(_T)\
            THEKOGANS_UTIL_DECLARE_SERIALIZABLE_VERSION(_T)\
            THEKOGANS_UTIL_DECLARE_SERIALIZABLE_Version(_T)\
            THEKOGANS_UTIL_DECLARE_SERIALIZABLE_CLASS_SIZE(_T)\
            THEKOGANS_UTIL_DECLARE_SERIALIZABLE_ClassSize(_T)\
            THEKOGANS_UTIL_DECLARE_SERIALIZABLE_GetContext(_T)

        /// \def THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_OVERRIDE(_T, version, classSize)
        /// Serializable overrides.
        #define THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_OVERRIDE(_T, version, classSize)\
            THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_VERSION(_T, version)\
            THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_Version(_T)\
            THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_CLASS_SIZE(_T, classSize)\
            THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_ClassSize(_T)\
            THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_GetContext(_T)

        /// \def THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_OVERRIDE(_T, version, classSize)
        /// Serializable overrides.
        #define THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_OVERRIDE_T(_T, version, classSize)\
            template<>\
            THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_VERSION(_T, version)\
            template<>\
            THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_Version(_T)\
            template<>\
            THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_CLASS_SIZE(_T, classSize)\
            template<>\
            THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_ClassSize(_T)\
            template<>\
            THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_GetContext(_T)

        /// \def THEKOGANS_UTIL_DECLARE_SERIALIZABLE(_T)
        /// Serializable declaration macro. Instantiate one of these
        /// in your class declaration. Ex;
        ///
        /// namespace thekogans {
        ///     namespace util {
        ///
        ///         struct _LIB_THEKOGANS_UTIL_DECL TimeSpec : public Serializable {
        ///             /// \brief
        ///             /// TimeSpec is a \see{Serializable}.
        ///             THEKOGANS_UTIL_DECLARE_SERIALIZABLE (TimeSpec)
        ///             ...
        ///         };
        ///
        ///     } // namespace util
        /// } // namespace thekogans
        #define THEKOGANS_UTIL_DECLARE_SERIALIZABLE(_T)\
            THEKOGANS_UTIL_DECLARE_DYNAMIC_CREATABLE (_T)\
            THEKOGANS_UTIL_DECLARE_SERIALIZABLE_OVERRIDE (_T)

        /// \def THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE(_T, version, classSize, ...)
        /// Serializable implementation macro. Instantiate one of these
        /// in your class cpp. Ex;
        ///
        /// namespace thekogans {
        ///     namespace util {
        ///
        ///         THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE (
        ///             thekogans::util::TimeSpec, 1, TimeSpec::SIZE)
        ///
        ///     } // namespace util
        /// } // namespace thekogans
        #define THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE(_T, version, classSize, ...)\
            THEKOGANS_UTIL_IMPLEMENT_DYNAMIC_CREATABLE (_T,\
                thekogans::util::Serializable::TYPE, ##__VA_ARGS__)\
            THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_OVERRIDE (_T, version, classSize)

        /// \def THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_S(_T, version, classSize, ...)
        /// Serializable implementation macro. Instantiate one of these
        /// in your \see{Singleton} derived class cpp.
        #define THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_S(_T, version, classSize, ...)\
            THEKOGANS_UTIL_IMPLEMENT_DYNAMIC_CREATABLE_S (_T,\
                thekogans::util::Serializable::TYPE, ##__VA_ARGS__)\
            THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_OVERRIDE (_T, version, classSize)

        /// \def THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_T(_T, version, classSize, ...)
        /// Serializable implementation macro. Instantiate one of these
        /// in your template instantiation class cpp.
        #define THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_T(_T, version, classSize, ...)\
            THEKOGANS_UTIL_IMPLEMENT_DYNAMIC_CREATABLE_T (_T,\
                thekogans::util::Serializable::TYPE, ##__VA_ARGS__)\
            THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_OVERRIDE_T (_T, version, classSize)

        /// \def THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_ST(_T, version, classSize, ...)
        /// Serializable implementation macro. Instantiate one of these
        /// in your \see{Singleton},  template instantiation class cpp.
        #define THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_ST(_T, version, classSize, ...)\
            THEKOGANS_UTIL_IMPLEMENT_DYNAMIC_CREATABLE_S (_T,\
                thekogans::util::Serializable::TYPE, ##__VA_ARGS__)\
            THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_OVERRIDE_T (_T, version, classSize)

        /// \struct Blob Serializable.h thekogans/util/Serializable.h
        ///
        /// \brief
        /// Blob is a standin for unrecognized types. Serializable is designed to
        /// marshal \see{DynamicCreatable} structured types. During marshaling the
        /// code might come accross a type that has not been registered. Instead of
        /// ignoring the data and potentially loosing information or throwing
        /// exceptions, Blob is used to contain unstructured bits. Blob is designed
        /// to put the bits back exactly as it found them. The limitation is that if
        /// you made a binary blob, you cannot store it as an XML or JSON blob. That
        /// kind of conversion requires knowledge of the underlying type.
        struct _LIB_THEKOGANS_UTIL_DECL Blob : public Serializable {
            /// \brief
            /// Declare \see{RefCounted} pointers.
            THEKOGANS_UTIL_DECLARE_REF_COUNTED_POINTERS (Blob)
            /// \brief
            /// Declare \see{DynamicCreatable} Type method.
            THEKOGANS_UTIL_DECLARE_DYNAMIC_CREATABLE_Type (Blob)
            /// \brief
            /// Declare \see{DynamicCreatable} BASES list.
            THEKOGANS_UTIL_DECLARE_DYNAMIC_CREATABLE_BASES (Blob)
            /// \brief
            /// Declare \see{DynamicCreatable} Bases method.
            THEKOGANS_UTIL_DECLARE_DYNAMIC_CREATABLE_Bases (Blob)

            /// \brief
            /// Blob type.
            SerializableHeader header;
            /// \brief
            /// Binary blob.
            Buffer buffer;
            /// \brief
            /// XML blob.
            pugi::xml_node node;
            /// \brief
            /// JSON blob.
            JSON::Object object;

            /// \brief
            /// Return the serializable version.
            /// \return Serializable version.
            virtual ui16 Version () const noexcept override;
            /// \brief
            /// Return the serializable class size.
            /// If CLASS_SIZE != 0, this serializable is fixed size.
            /// If CLASS_SIZE == 0, this serializable is variable size
            /// and you need to call Size to get the size of this instance.
            /// \return Serializable class size.
            virtual std::size_t ClassSize () const noexcept override;

            /// \brief
            /// Read the serializable from the given serializer.
            /// \param[in] header_ SerializableHeader to deserialize.
            /// \param[in] serializer Serializer to read the serializable from.
            virtual void Read (
                const SerializableHeader &header_,
                Serializer &serializer) override;
            /// \brief
            /// Write the serializable to the given serializer.
            /// \param[out] serializer Serializer to write the serializable to.
            virtual void Write (Serializer &serializer) const override;

            /// \brief
            /// Return the serializable XML size.
            /// \return Serializable XML size.
            virtual std::size_t SizeXML () const noexcept override;
            /// \brief
            /// Read the Serializable from an XML DOM.
            /// \param[in] header_ SerializableHeader to deserialize.
            /// \param[in] node XML DOM representation of a Serializable.
            virtual void ReadXML (
                const SerializableHeader &header_,
                const pugi::xml_node &node_) override;
            /// \brief
            /// Write a Serializable to the XML DOM.
            /// \param[out] node_ Parent node.
            virtual void WriteXML (pugi::xml_node &node_) const override;

            /// \brief
            /// Return the serializable JSON size.
            /// \return Serializable JSON size.
            virtual std::size_t SizeJSON () const noexcept override;
            /// \brief
            /// Read the Serializable from an JSON DOM.
            /// \param[in] header_ SerializableHeader to deserialize.
            /// \param[in] object_ JSON DOM representation of a Serializable.
            virtual void ReadJSON (
                const SerializableHeader &header_,
                const JSON::Object &object_) override;
            /// \brief
            /// Write a Serializable to the JSON DOM.
            /// \param[out] object_ Parent node.
            virtual void WriteJSON (JSON::Object &object_) const override;
        };

        /// \brief
        /// Serializable insertion operator.
        /// \param[in] serializer Where to serialize the serializable.
        /// \param[in] serializable Serializable to serialize.
        /// \return serializer.
        _LIB_THEKOGANS_UTIL_DECL Serializer & _LIB_THEKOGANS_UTIL_API operator << (
            Serializer &serializer,
            const Serializable &serializable);
        /// \brief
        /// Serializable insertion operator.
        /// \param[in] node Where to serialize the serializable.
        /// \param[in] serializable Serializable to serialize.
        /// \return node.
        _LIB_THEKOGANS_UTIL_DECL pugi::xml_node & _LIB_THEKOGANS_UTIL_API operator << (
            pugi::xml_node &node,
            const Serializable &serializable);
        /// \brief
        /// Serializable insertion operator.
        /// \param[in] object Where to serialize the serializable.
        /// \param[in] serializable Serializable to serialize.
        /// \return node.
        _LIB_THEKOGANS_UTIL_DECL JSON::Object & _LIB_THEKOGANS_UTIL_API operator << (
            JSON::Object &object,
            const Serializable &serializable);

        /// \brief
        /// Serializable extraction operator.
        /// \param[in] serializer Serializer to extract from.
        /// \param[out] serializable Serializable to extract.
        /// \return serializer.
        _LIB_THEKOGANS_UTIL_DECL Serializer & _LIB_THEKOGANS_UTIL_API operator >> (
            Serializer &serializer,
            Serializable &serializable);
        /// \brief
        /// Serializable extraction operator.
        /// \param[in] node Serializer to extract from.
        /// \param[out] serializable Serializable to extract.
        /// \return serializer.
        _LIB_THEKOGANS_UTIL_DECL const pugi::xml_node & _LIB_THEKOGANS_UTIL_API operator >> (
            const pugi::xml_node &node,
            Serializable &serializable);
        /// \brief
        /// Serializable extraction operator.
        /// \param[in] object Serializer to extract from.
        /// \param[out] serializable Serializable to extract.
        /// \return serializer.
        _LIB_THEKOGANS_UTIL_DECL const JSON::Object & _LIB_THEKOGANS_UTIL_API operator >> (
            const JSON::Object &object,
            Serializable &serializable);

        /// \brief
        /// Serializable::SharedPtr extraction operator.
        /// \param[in] serializer Serializer to extract from.
        /// \param[out] serializable Serializable to extract.
        /// \return serializer.
        _LIB_THEKOGANS_UTIL_DECL Serializer & _LIB_THEKOGANS_UTIL_API operator >> (
            Serializer &serializer,
            Serializable::SharedPtr &serializable);
        /// \brief
        /// Serializable::SharedPtr extraction operator.
        /// \param[in] node Serializer to extract from.
        /// \param[out] serializable Serializable to extract.
        /// \return serializer.
        _LIB_THEKOGANS_UTIL_DECL const pugi::xml_node & _LIB_THEKOGANS_UTIL_API operator >> (
            const pugi::xml_node &node,
            Serializable::SharedPtr &serializable);
        /// \brief
        /// Serializable::SharedPtr extraction operator.
        /// \param[in] object Serializer to extract from.
        /// \param[out] serializable Serializable to extract.
        /// \return serializer.
        _LIB_THEKOGANS_UTIL_DECL const JSON::Object & _LIB_THEKOGANS_UTIL_API operator >> (
            const JSON::Object &object,
            Serializable::SharedPtr &serializable);

        /// \def THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_EXTRACTION_OPERATORS(_T)
        /// Implement extraction operators for _T::SharedPtr.
        #define THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_EXTRACTION_OPERATORS(_T)\
            inline thekogans::util::Serializer & _LIB_THEKOGANS_UTIL_API operator >> (\
                    thekogans::util::Serializer &serializer,\
                    _T::SharedPtr &serializable) {\
                Serializable::SharedPtr base;\
                serializer >> base;\
                serializable = base;\
                return serializer;\
            }\
            inline const pugi::xml_node & _LIB_THEKOGANS_UTIL_API operator >> (\
                    const pugi::xml_node &node,\
                    _T::SharedPtr &serializable) {\
                Serializable::SharedPtr base;\
                node >> base;\
                serializable = base;\
                return node;\
            }\
            inline const thekogans::util::JSON::Object & _LIB_THEKOGANS_UTIL_API operator >> (\
                    const thekogans::util::JSON::Object &object,\
                    _T::SharedPtr &serializable) {\
                Serializable::SharedPtr base;\
                object >> base;\
                serializable = base;\
                return object;\
            }

        /// \struct ValueParser<SerializableHeader> Serializable.h thekogans/util/Serializable.h
        ///
        /// \brief
        /// Specialization of \see{ValueParser} for \see{SerializableHeader}.
        template<>
        struct _LIB_THEKOGANS_UTIL_DECL ValueParser<SerializableHeader> {
        private:
            /// \brief
            /// \see{SerializableHeader} to parse.
            SerializableHeader &value;
            /// \brief
            /// Parses \see{SerializableHeader::type}.
            ValueParser<std::string> typeParser;
            /// \brief
            /// Parses \see{SerializableHeader::version}.
            ValueParser<ui16> versionParser;
            /// \brief
            /// Parses \see{SerializableHeader::size}.
            ValueParser<SizeT> sizeParser;
            /// \enum
            /// \see{SerializableHeader} parser is a state machine.
            /// These are it's various states.
            enum {
                /// \brief
                /// We have everything we need.
                STATE_NOTHING,
                /// \brief
                /// Next value is \see{SerializableHeader::type}.
                STATE_TYPE,
                /// \brief
                /// Next value is \see{SerializableHeader::version}.
                STATE_VERSION,
                /// \brief
                /// Next value is \see{SerializableHeader::size}.
                STATE_SIZE
            } state;

        public:
            /// \brief
            /// ctor.
            /// \param[out] value_ Value to parse.
            explicit ValueParser (
                    SerializableHeader &value_,
                    Serializer &serializer) :
                    value (value_),
                    typeParser (value.type),
                    versionParser (value.version),
                    sizeParser (value.size),
                    state (STATE_NOTHING) {
                Reset (serializer);
            }

            /// \brief
            /// Rewind the sub-parsers to get them ready for the next value.
            void Reset (Serializer &serializer);

            /// \brief
            /// Try to parse a \see{SerializableHeader} from the given serializer.
            /// \param[in] serializer Contains a complete or partial \see{SerializableHeader}.
            /// \return true == \see{SerializableHeader} was successfully parsed,
            /// false == call back with more data.
            bool ParseValue (Serializer &serializer);
        };

        /// \struct ValueParser<Serializable> Serializable.h thekogans/util/Serializable.h
        ///
        /// \brief
        /// Specialization of \see{ValueParser} for \see{Serializable}.
        template<>
        struct _LIB_THEKOGANS_UTIL_DECL ValueParser<Serializable> {
        protected:
            /// \brief
            /// Serializable to parse.
            Serializable &value;
            /// \brief
            /// Default serializable size;
            static const std::size_t DEFAULT_MAX_SERIALIZABLE_SIZE = 2 * 1024 * 1024;
            /// \brief
            /// Used to twart ddos attacks. The generic 2MB might be too much.
            /// Tune this value to protect your application.
            const std::size_t maxSerializableSize;
            /// \brief
            /// Parsed serializable header.
            SerializableHeader header;
            /// \brief
            /// Parsed serializable payload.
            NetworkBuffer payload;
            /// \brief
            /// Serializable header parser.
            ValueParser<SerializableHeader> headerParser;
            /// \enum
            /// The parser is a state machine. It has two states.
            enum {
                /// \brief
                /// We're looking for a header.
                STATE_HEADER,
                /// \brief
                /// We're looting for the payload.
                STATE_SERIALIZABLE
            } state;

        public:
            /// \brief
            /// ctor.
            /// \param[out] value_ Value to parse.
            /// \param[in] maxSerializableSize_ Used to protect the code against malicious actors.
            ValueParser (
                Serializable &value_,
                Serializer &serializer,
                std::size_t maxSerializableSize_ = DEFAULT_MAX_SERIALIZABLE_SIZE) :
                value (value_),
                maxSerializableSize (maxSerializableSize_),
                headerParser (header, serializer),
                state (STATE_HEADER) {}

            /// \brief
            /// Rewind the sub-parsers to get them ready for the next value.
            void Reset (Serializer &serializer);

            /// \brief
            /// Try to parse a \see{Serializable::SharedPtr} from the given serializer.
            /// \param[in] serializer Contains a complete or partial \see{Serializable}.
            /// \return true == \see{Serializable} was successfully parsed,
            /// false == call back with more data.
            bool ParseValue (Serializer &serializer);
        };

        /// \struct ValueParser<Serializable::SharedPtr> Serializable.h thekogans/util/Serializable.h
        ///
        /// \brief
        /// Specialization of \see{ValueParser} for \see{Serializable::SharedPtr}.
        template<>
        struct _LIB_THEKOGANS_UTIL_DECL ValueParser<Serializable::SharedPtr> {
            /// \brief
            /// Default serializable size;
            static const std::size_t DEFAULT_MAX_SERIALIZABLE_SIZE = 2 * 1024 * 1024;

        protected:
            /// \brief
            /// Serializable to parse.
            Serializable::SharedPtr &value;
            /// \brief
            /// Used to twart ddos attacks. The generic 2MB might be too much.
            /// Tune this value to protect your application.
            const std::size_t maxSerializableSize;
            /// \brief
            /// Parsed serializable header.
            SerializableHeader header;
            /// \brief
            /// Parsed serializable payload.
            NetworkBuffer payload;
            /// \brief
            /// Serializable header parser.
            ValueParser<SerializableHeader> headerParser;
            /// \enum
            /// The parser is a state machine. It has two states.
            enum {
                /// \brief
                /// We're looking for a header.
                STATE_HEADER,
                /// \brief
                /// We're looting for the payload.
                STATE_SERIALIZABLE
            } state;

        public:
            /// \brief
            /// ctor.
            /// \param[out] value_ Value to parse.
            /// \param[in] maxSerializableSize_ Used to protect the code against malicious actors.
            ValueParser (
                Serializable::SharedPtr &value_,
                Serializer &serializer,
                std::size_t maxSerializableSize_ = DEFAULT_MAX_SERIALIZABLE_SIZE) :
                value (value_),
                maxSerializableSize (maxSerializableSize_),
                headerParser (header, serializer),
                state (STATE_HEADER) {}

            /// \brief
            /// Rewind the sub-parsers to get them ready for the next value.
            void Reset (Serializer &serializer);

            /// \brief
            /// Try to parse a \see{Serializable::SharedPtr} from the given serializer.
            /// \param[in] serializer Contains a complete or partial \see{Serializable::SharedPtr}.
            /// \return true == \see{Serializable::SharedPtr} was successfully parsed,
            /// false == call back with more data.
            bool ParseValue (Serializer &serializer);
        };

        /// \def THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_VALUE_PARSER(_T)
        /// Implement a value parser for _T::SharedPtr.
        #define THEKOGANS_UTIL_IMPLEMENT_SERIALIZABLE_VALUE_PARSER(_T)\
            template<>\
            struct _LIB_THEKOGANS_UTIL_DECL ValueParser<_T::SharedPtr> {\
            private:\
                _T::SharedPtr &value;\
                Serializable::SharedPtr base;\
                thekogans::util::ValueParser<thekogans::util::Serializable::SharedPtr> baseParser;\
            public:\
                ValueParser (\
                    _T::SharedPtr &value_,\
                    thekogans::util::Serializer &serializer,\
                    std::size_t maxSerializableSize =\
                        thekogans::util::ValueParser<thekogans::util::Serializable::SharedPtr>::DEFAULT_MAX_SERIALIZABLE_SIZE) :\
                    value (value_),\
                    base (value_),\
                    baseParser (base, serializer, maxSerializableSize) {}\
                void Reset (thekogans::util::Serializer &serializer) {\
                    baseParser.Reset (serializer);\
                }\
                bool ParseValue (thekogans::util::Serializer &serializer) {\
                    if (baseParser.ParseValue (serializer)) {\
                        value = base;\
                        return true;\
                    }\
                    return false;\
                }\
            };

    } // Namespace util
} // namespace thekogans

#endif // !defined (__thekogans_util_Serializable_h)

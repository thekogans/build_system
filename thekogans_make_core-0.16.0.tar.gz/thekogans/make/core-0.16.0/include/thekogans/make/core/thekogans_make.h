// Copyright 2011 Boris Kogan (boris@thekogans.net)
//
// This file is part of thekogans_make_core.
//
// thekogans_make_core is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// thekogans_make_core is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with thekogans_make_core. If not, see <http://www.gnu.org/licenses/>.

#if !defined (__thekogans_make_core_thekogans_make_h)
#define __thekogans_make_core_thekogans_make_h

#include <memory>
#include <string>
#include <vector>
#include <set>
#include <map>
#include "pugixml/pugixml.hpp"
#include "thekogans/util/Heap.h"
#include "thekogans/util/GUID.h"
#include "thekogans/make/core/Config.h"
#include "thekogans/make/core/Value.h"
#include "thekogans/make/core/Installer.h"
#include "thekogans/make/core/Toolchain.h"
#include "thekogans/make/core/Utils.h"

namespace thekogans {
    namespace make {
        namespace core {

            /// \struct thekogans_make thekogans_make.h thekogans/make/thekogans_make.h
            ///
            /// \brief
            /// Used to retrieve various info from the project's thekogans_make.xml file.

            struct _LIB_THEKOGANS_MAKE_CORE_DECL thekogans_make : public util::RefCounted {
                THEKOGANS_UTIL_DECLARE_REF_COUNTED_POINTERS (thekogans_make)
                THEKOGANS_UTIL_DECLARE_STD_ALLOCATOR_FUNCTIONS

                static const char * const ATTR_ORGANIZATION;
                static const char * const ATTR_PROJECT;
                static const char * const ATTR_PROJECT_TYPE;
                static const char * const ATTR_MAJOR_VERSION;
                static const char * const ATTR_MINOR_VERSION;
                static const char * const ATTR_PATCH_VERSION;
                static const char * const ATTR_NAMING_CONVENTION;
                static const char * const ATTR_BUILD_CONFIG;
                static const char * const ATTR_BUILD_TYPE;
                static const char * const ATTR_GUID;
                static const char * const ATTR_SCHEMA_VERSION;
                static const char * const ATTR_CONDITION;
                static const char * const ATTR_PREFIX;
                static const char * const ATTR_DESTINATION_PREFIX;
                static const char * const ATTR_NAME;
                static const char * const ATTR_VALUE;
                static const char * const ATTR_BRANCH;
                static const char * const ATTR_VERSION;
                static const char * const ATTR_EXAMPLE;
                static const char * const ATTR_CONFIG;
                static const char * const ATTR_TYPE;
                static const char * const ATTR_PRIVATE;
                static const char * const ATTR_FLAGS;

                static const char * const TAG_THEKOGANS_MAKE;
                static const char * const TAG_CONSTANTS;
                static const char * const TAG_CONSTANT;
                static const char * const TAG_FEATURES;
                static const char * const TAG_FEATURE;
                static const char * const TAG_PLUGIN_HOSTS;
                static const char * const TAG_DEPENDENCIES;
                static const char * const TAG_DEPENDENCY;
                static const char * const TAG_PRECOMPILED_HEADER;
                static const char * const TAG_FILE;
                static const char * const TAG_OUTPUT_FILE;
                static const char * const TAG_PROJECT;
                static const char * const TAG_TOOLCHAIN;
                static const char * const TAG_PACKAGE;
                static const char * const TAG_LIBRARY;
                static const char * const TAG_INCLUDE_DIRECTORIES;
                static const char * const TAG_INCLUDE_DIRECTORY;
                static const char * const TAG_PREPROCESSOR_DEFINITIONS;
                static const char * const TAG_PREPROCESSOR_DEFINITION;
                static const char * const TAG_LINKER_FLAGS;
                static const char * const TAG_LINKER_FLAG;
                static const char * const TAG_LIBRARIAN_FLAGS;
                static const char * const TAG_LIBRARIAN_FLAG;
                static const char * const TAG_LINK_LIBRARIES;
                static const char * const TAG_LINK_LIBRARY;
                static const char * const TAG_MASM_FLAGS;
                static const char * const TAG_MASM_FLAG;
                static const char * const TAG_MASM_PREPROCESSOR_DEFINITIONS;
                static const char * const TAG_MASM_PREPROCESSOR_DEFINITION;
                static const char * const TAG_MASM_HEADERS;
                static const char * const TAG_MASM_HEADER;
                static const char * const TAG_MASM_SOURCES;
                static const char * const TAG_MASM_SOURCE;
                static const char * const TAG_MASM_TESTS;
                static const char * const TAG_MASM_TEST;
                static const char * const TAG_NASM_FLAGS;
                static const char * const TAG_NASM_FLAG;
                static const char * const TAG_NASM_PREPROCESSOR_DEFINITIONS;
                static const char * const TAG_NASM_PREPROCESSOR_DEFINITION;
                static const char * const TAG_NASM_HEADERS;
                static const char * const TAG_NASM_HEADER;
                static const char * const TAG_NASM_SOURCES;
                static const char * const TAG_NASM_SOURCE;
                static const char * const TAG_NASM_TESTS;
                static const char * const TAG_NASM_TEST;
                static const char * const TAG_C_FLAGS;
                static const char * const TAG_C_FLAG;
                static const char * const TAG_C_PREPROCESSOR_DEFINITIONS;
                static const char * const TAG_C_PREPROCESSOR_DEFINITION;
                static const char * const TAG_C_HEADERS;
                static const char * const TAG_C_HEADER;
                static const char * const TAG_C_SOURCES;
                static const char * const TAG_C_SOURCE;
                static const char * const TAG_C_TESTS;
                static const char * const TAG_C_TEST;
                static const char * const TAG_CPP_FLAGS;
                static const char * const TAG_CPP_FLAG;
                static const char * const TAG_CPP_PREPROCESSOR_DEFINITIONS;
                static const char * const TAG_CPP_PREPROCESSOR_DEFINITION;
                static const char * const TAG_CPP_HEADERS;
                static const char * const TAG_CPP_HEADER;
                static const char * const TAG_CPP_SOURCES;
                static const char * const TAG_CPP_SOURCE;
                static const char * const TAG_CPP_TESTS;
                static const char * const TAG_CPP_TEST;
                static const char * const TAG_OBJECTIVE_C_FLAGS;
                static const char * const TAG_OBJECTIVE_C_FLAG;
                static const char * const TAG_OBJECTIVE_C_PREPROCESSOR_DEFINITIONS;
                static const char * const TAG_OBJECTIVE_C_PREPROCESSOR_DEFINITION;
                static const char * const TAG_OBJECTIVE_C_HEADERS;
                static const char * const TAG_OBJECTIVE_C_HEADER;
                static const char * const TAG_OBJECTIVE_C_SOURCES;
                static const char * const TAG_OBJECTIVE_C_SOURCE;
                static const char * const TAG_OBJECTIVE_C_TESTS;
                static const char * const TAG_OBJECTIVE_C_TEST;
                static const char * const TAG_OBJECTIVE_CPP_FLAGS;
                static const char * const TAG_OBJECTIVE_CPP_FLAG;
                static const char * const TAG_OBJECTIVE_CPP_PREPROCESSOR_DEFINITIONS;
                static const char * const TAG_OBJECTIVE_CPP_PREPROCESSOR_DEFINITION;
                static const char * const TAG_OBJECTIVE_CPP_HEADERS;
                static const char * const TAG_OBJECTIVE_CPP_HEADER;
                static const char * const TAG_OBJECTIVE_CPP_SOURCES;
                static const char * const TAG_OBJECTIVE_CPP_SOURCE;
                static const char * const TAG_OBJECTIVE_CPP_TESTS;
                static const char * const TAG_OBJECTIVE_CPP_TEST;
                static const char * const TAG_REGEX;
                static const char * const TAG_CUSTOM_BUILD;
                static const char * const TAG_OUTPUTS;
                static const char * const TAG_OUTPUT;
                static const char * const TAG_MESSAGE;
                static const char * const TAG_RECIPE;
                static const char * const TAG_RESOURCES;
                static const char * const TAG_RESOURCE;
                static const char * const TAG_RC_FLAGS;
                static const char * const TAG_RC_FLAG;
                static const char * const TAG_RC_PREPROCESSOR_DEFINITIONS;
                static const char * const TAG_RC_PREPROCESSOR_DEFINITION;
                static const char * const TAG_RC_SOURCES;
                static const char * const TAG_RC_SOURCE;
                static const char * const TAG_SUBSYSTEM;
                static const char * const TAG_DEF_FILE;
                static const char * const TAG_BUNDLE;
                static const char * const TAG_INFO_PLIST;
                static const char * const TAG_FRAMEWORKS;
                static const char * const TAG_FRAMEWORK;
                static const char * const TAG_PLUGINS;
                static const char * const TAG_PLUGIN;
                static const char * const TAG_SHARED_SUPPORTS;
                static const char * const TAG_SHARED_SUPPORT;
                static const char * const TAG_IF;
                static const char * const TAG_CHOOSE;
                static const char * const TAG_WHEN;
                static const char * const TAG_OTHERWISE;
                static const char * const TAG_INFO;
                static const char * const TAG_WARNING;
                static const char * const TAG_ERROR;

                static const char * const VAR_PROJECT_ROOT;
                static const char * const VAR_CONFIG_FILE;
                static const char * const VAR_GENERATOR;
                static const char * const VAR_CONFIG;
                static const char * const VAR_TYPE;
                static const char * const VAR_PROJECT_DIRECTORY;
                static const char * const VAR_BUILD_DIRECTORY;
                static const char * const VAR_VERSION;
                static const char * const VAR_LINK_LIBRARY_SUFFIX;

                // ctor arguments.
                std::string project_root;
                std::string config_file;
                std::string generator;
                std::string config;
                std::string type;
                // thekogans_make tag attributes.
                std::string organization;
                std::string project;
                std::string project_type;
                std::string major_version;
                std::string minor_version;
                std::string patch_version;
                std::string naming_convention;
                std::string build_config;
                std::string build_type;
                util::GUID guid;
                std::string schema_version;
                // thekogans_make body.
                std::set<std::string> features;
                struct _LIB_THEKOGANS_MAKE_CORE_DECL Dependency : public util::RefCounted {
                    THEKOGANS_UTIL_DECLARE_REF_COUNTED_POINTERS (Dependency)

                    const thekogans_make &dependent;
                    bool isPrivate;

                    Dependency (
                        const thekogans_make &dependent_,
                        bool isPrivate_) :
                        dependent (dependent_),
                        isPrivate (isPrivate_) {}
                    virtual ~Dependency () {}

                    inline const thekogans_make &GetDependent () const {
                        return dependent;
                    }
                    inline bool IsPrivate () const {
                        return isPrivate;
                    }

                    virtual std::string GetOrganization () const {
                        return std::string ();
                    }
                    virtual std::string GetName () const {
                        return std::string ();
                    }
                    virtual std::string GetProjectRoot () const {
                        return std::string ();
                    }
                    virtual std::string GetConfigFile () const {
                        return std::string ();
                    }
                    virtual std::string GetGenerator () const {
                        return std::string ();
                    }
                    virtual std::string GetConfig () const {
                        return std::string ();
                    }
                    virtual std::string GetType () const {
                        return std::string ();
                    }

                    virtual bool EquivalentTo (const Dependency & /*dependency*/) const = 0;

                    using VersionAndBranch = std::pair<std::string, std::string>;
                    using VersionSet = std::set<VersionAndBranch>;
                    using Versions = std::map<std::string, VersionSet>;

                    virtual void CollectVersions (Versions & /*versions*/) const {}
                    virtual void SetMinVersion (
                        Versions & /*versions*/,
                        std::set<std::string> & /*visitedDependencies*/) const {}

                    virtual void GetCommonPreprocessorDefinitions (std::set<std::string> & /*preprocessorDefinitions*/) const {}
                    virtual void GetFeatures (std::set<std::string> & /*features*/) const {}
                    virtual bool HaveFeature (const std::string & /*feature*/) const {
                        return false;
                    }

                    virtual void GetIncludeDirectories (std::set<std::string> & /*include_directories*/) const {}
                    virtual void GetLibraryDirectories (std::set<std::string> & /*library_directories*/) const {}
                    virtual void GetFrameworkDirectories (std::set<std::string> & /*framework_directories*/) const {}
                    virtual void GetLinkerFlags (std::set<std::string> & /*linker_flags*/) const {}
                    virtual void GetLibrarianFlags (std::set<std::string> & /*librarian_flags*/) const {}
                    virtual void GetMasmFlags (std::set<std::string> & /*masm_flags*/) const {}
                    virtual void GetMasmPreprocessorDefinitions (std::set<std::string> & /*masm_preprocessor_definitions*/) const {}
                    virtual void GetNasmFlags (std::set<std::string> & /*nasm_flags*/) const {}
                    virtual void GetNasmPreprocessorDefinitions (std::set<std::string> & /*nasm_preprocessor_definitions*/) const {}
                    virtual void GetCFlags (std::set<std::string> & /*c_flags*/) const {}
                    virtual void GetCPreprocessorDefinitions (std::set<std::string> & /*c_preprocessor_definitions*/) const {}
                    virtual void GetCPPFlags (std::set<std::string> & /*cpp_flags*/) const {}
                    virtual void GetCPPPreprocessorDefinitions (std::set<std::string> & /*cpp_preprocessor_definitions*/) const {}
                    virtual void GetObjectiveCFlags (std::set<std::string> & /*objective_c_flags*/) const {}
                    virtual void GetObjectiveCPreprocessorDefinitions (std::set<std::string> & /*objective_c_preprocessor_definitions*/) const {}
                    virtual void GetObjectiveCPPFlags (std::set<std::string> & /*objective_cpp_flags*/) const {}
                    virtual void GetObjectiveCPPPreprocessorDefinitions (std::set<std::string> & /*objective_cpp_preprocessor_definitions*/) const {}
                    virtual void GetRCFlags (std::set<std::string> & /*rc_flags*/) const {}
                    virtual void GetRCPreprocessorDefinitions (std::set<std::string> & /*rc_preprocessor_definitions*/) const {}

                    // Libraries must come is strict order. We can't use a set here.
                    virtual void GetLinkLibraries (std::set<std::string> & /*link_libraries*/) const {}
                    virtual void GetSharedLibraries (std::set<std::string> & /*shared_libraries*/) const {}

                    virtual bool IsInstalled () const {
                        return true;
                    }
                    virtual std::string ToString (util::ui32 /*indentationLevel*/ = 0) const {
                        return std::string ();
                    }

                    virtual void ListDependencies (util::ui32 /*indentationLevel*/ = 0) const {}

                    THEKOGANS_UTIL_DISALLOW_COPY_MOVE_AND_ASSIGN (Dependency)
                };
                std::vector<Dependency::SharedPtr> plugin_hosts;
                std::vector<Dependency::SharedPtr> dependencies;
                struct _LIB_THEKOGANS_MAKE_CORE_DECL PrecompiledHeader {
                    enum Type {
                        None,
                        Use,
                        Create
                    } type;
                    std::string file;
                    std::string outputFile;

                    static const char * const TYPE_NONE;
                    static const char * const TYPE_USE;
                    static const char * const TYPE_CREATE;

                    static std::string TypeTostring (Type type);
                    static Type stringToType (const std::string &type);

                    PrecompiledHeader () :
                        type (None) {}
                } precompiled_header;
                struct _LIB_THEKOGANS_MAKE_CORE_DECL StringList : public util::RefCounted {
                    THEKOGANS_UTIL_DECLARE_REF_COUNTED_POINTERS (StringList)
                    THEKOGANS_UTIL_DECLARE_STD_ALLOCATOR_FUNCTIONS

                    bool isPrivate;
                    std::vector<std::string> strings;

                    StringList () :
                        isPrivate (false) {}

                    THEKOGANS_UTIL_DISALLOW_COPY_AND_ASSIGN (StringList)
                };
                struct _LIB_THEKOGANS_MAKE_CORE_DECL FileList : public util::RefCounted {
                    THEKOGANS_UTIL_DECLARE_REF_COUNTED_POINTERS (FileList)
                    THEKOGANS_UTIL_DECLARE_STD_ALLOCATOR_FUNCTIONS

                    std::string prefix;
                    bool isPrivate;
                    std::string destinationPrefix;
                    struct _LIB_THEKOGANS_MAKE_CORE_DECL File : public util::RefCounted {
                        THEKOGANS_UTIL_DECLARE_REF_COUNTED_POINTERS (File)
                        THEKOGANS_UTIL_DECLARE_STD_ALLOCATOR_FUNCTIONS

                        std::string name;
                        struct _LIB_THEKOGANS_MAKE_CORE_DECL CustomBuild : public util::RefCounted {
                            THEKOGANS_UTIL_DECLARE_REF_COUNTED_POINTERS (CustomBuild)
                            THEKOGANS_UTIL_DECLARE_STD_ALLOCATOR_FUNCTIONS

                            std::vector<std::string> outputs;
                            std::vector<std::string> dependencies;
                            std::string message;
                            std::string recipe;

                            CustomBuild () {}
                            CustomBuild (
                                const std::string &message_,
                                const std::string &recipe_) :
                                message (message_),
                                recipe (recipe_) {}

                            THEKOGANS_UTIL_DISALLOW_COPY_AND_ASSIGN (CustomBuild)
                        };
                        CustomBuild::SharedPtr customBuild;
                        PrecompiledHeader precompiled_header;

                        File () {}
                        File (
                            const std::string &name_,
                            bool createCustomBuild = false) :
                            name (name_),
                            customBuild (createCustomBuild ? new CustomBuild : 0) {}

                        THEKOGANS_UTIL_DISALLOW_COPY_AND_ASSIGN (File)
                    };
                    std::vector<File::SharedPtr> files;

                    explicit FileList (const std::string &destinationPrefix_) :
                        isPrivate (true),
                        destinationPrefix (destinationPrefix_) {}

                    THEKOGANS_UTIL_DISALLOW_COPY_AND_ASSIGN (FileList)
                };
                struct _LIB_THEKOGANS_MAKE_CORE_DECL IncludeDirectoriesList : public util::RefCounted {
                    THEKOGANS_UTIL_DECLARE_REF_COUNTED_POINTERS (IncludeDirectoriesList)
                    THEKOGANS_UTIL_DECLARE_STD_ALLOCATOR_FUNCTIONS

                    std::string prefix;
                    bool isPrivate;
                    std::vector<std::string> paths;

                    IncludeDirectoriesList () :
                        isPrivate (false) {}

                    THEKOGANS_UTIL_DISALLOW_COPY_AND_ASSIGN (IncludeDirectoriesList)
                };
                std::vector<IncludeDirectoriesList::SharedPtr> include_directories;
                std::vector<std::string> preprocessor_definitions;
                std::vector<std::string> linker_flags;
                std::vector<std::string> librarian_flags;
                std::vector<std::string> masm_flags;
                std::vector<std::string> masm_preprocessor_definitions;
                std::vector<FileList::SharedPtr> masm_headers;
                std::vector<FileList::SharedPtr> masm_sources;
                std::vector<FileList::SharedPtr> masm_tests;
                std::vector<std::string> nasm_flags;
                std::vector<std::string> nasm_preprocessor_definitions;
                std::vector<FileList::SharedPtr> nasm_headers;
                std::vector<FileList::SharedPtr> nasm_sources;
                std::vector<FileList::SharedPtr> nasm_tests;
                std::vector<std::string> c_flags;
                std::vector<std::string> c_preprocessor_definitions;
                std::vector<FileList::SharedPtr> c_headers;
                std::vector<FileList::SharedPtr> c_sources;
                std::vector<FileList::SharedPtr> c_tests;
                std::vector<std::string> cpp_flags;
                std::vector<std::string> cpp_preprocessor_definitions;
                std::vector<FileList::SharedPtr> cpp_headers;
                std::vector<FileList::SharedPtr> cpp_sources;
                std::vector<FileList::SharedPtr> cpp_tests;
                std::vector<std::string> objective_c_flags;
                std::vector<std::string> objective_c_preprocessor_definitions;
                std::vector<FileList::SharedPtr> objective_c_headers;
                std::vector<FileList::SharedPtr> objective_c_sources;
                std::vector<FileList::SharedPtr> objective_c_tests;
                std::vector<std::string> objective_cpp_flags;
                std::vector<std::string> objective_cpp_preprocessor_definitions;
                std::vector<FileList::SharedPtr> objective_cpp_headers;
                std::vector<FileList::SharedPtr> objective_cpp_sources;
                std::vector<FileList::SharedPtr> objective_cpp_tests;
                std::vector<FileList::SharedPtr> resources;
                // Windows specific.
                std::vector<std::string> rc_flags;
                std::vector<std::string> rc_preprocessor_definitions;
                std::vector<FileList::SharedPtr> rc_sources;
                std::string subsystem;
                std::string def_file;
                // OSX specific.
                struct _LIB_THEKOGANS_MAKE_CORE_DECL Bunde {
                    std::string info_plist;
                    std::vector<std::string> resources;
                    std::vector<std::string> frameworks;
                    std::vector<std::string> plugins;
                    std::vector<std::string> shared_supports;
                } bundle;
                SymbolTable globalSymbolTable;
                SymbolTable localSymbolTable;

                static const thekogans_make &GetConfig (
                    const std::string &project_root,
                    const std::string &config_file,
                    const std::string &generator = std::string (),
                    const std::string &config = std::string (),
                    const std::string &type = std::string ());

                std::string GetVersion () const;

                void CheckDependencies () const;
                void ListDependencies (util::ui32 indentationLevel) const;
                Dependency::SharedPtr GetDependency (
                    const std::string &organization,
                    const std::string &name) const;

                void GetFeatures (std::set<std::string> &features_) const;
                bool HasFeature (const std::string &feature) const;
                void GetIncludeDirectories (std::set<std::string> &include_directories_) const;
                void GetLibraryDirectories (std::set<std::string> &include_directories_) const;
                void GetFrameworkDirectories (std::set<std::string> &framework_directories) const;
                void GetLinkLibraries (std::set<std::string> &link_libraries_) const;
                void GetSharedLibraries (std::set<std::string> &shared_libraries) const;

                void GetLinkerFlags (std::set<std::string> &linker_flags_) const;
                void GetLibrarianFlags (std::set<std::string> &librarian_flags_) const;
                void GetMasmFlags (std::set<std::string> &masm_flags_) const;
                void GetMasmPreprocessorDefinitions (std::set<std::string> &masm_preprocessor_definitions_) const;
                void GetNasmFlags (std::set<std::string> &nasm_flags_) const;
                void GetNasmPreprocessorDefinitions (std::set<std::string> &nasm_preprocessor_definitions_) const;
                void GetCFlags (std::set<std::string> &c_flags_) const;
                void GetCPreprocessorDefinitions (std::set<std::string> &c_preprocessor_definitions_) const;
                void GetCPPFlags (std::set<std::string> &cpp_flags_) const;
                void GetCPPPreprocessorDefinitions (std::set<std::string> &cpp_preprocessor_definitions_) const;
                void GetObjectiveCFlags (std::set<std::string> &objective_c_flags_) const;
                void GetObjectiveCPreprocessorDefinitions (std::set<std::string> &objective_c_preprocessor_definitions_) const;
                void GetObjectiveCPPFlags (std::set<std::string> &objective_cpp_flags_) const;
                void GetObjectiveCPPPreprocessorDefinitions (std::set<std::string> &objective_cpp_preprocessor_definitions_) const;
                void GetRCFlags (std::set<std::string> &rc_flags_) const;
                void GetRCPreprocessorDefinitions (std::set<std::string> &rc_preprocessor_definitions_) const;

                inline bool HasGoal () const {
                    return
                        !masm_sources.empty () ||
                        !nasm_sources.empty () ||
                        !c_sources.empty () ||
                        !cpp_sources.empty () ||
                        !objective_c_sources.empty () ||
                        !objective_cpp_sources.empty () ||
                        !rc_sources.empty ();
                }

                bool Eval (const char *expression) const;
                Value LookupSymbol (const std::string &symbol) const;
                std::string Expand (const char *format) const;

                std::string GetProjectDependencyVersion (
                    const std::string &organization,
                    const std::string &project,
                    const std::string &example) const;
                std::string GetToolchainDependencyVersion (
                    const std::string &organization,
                    const std::string &project) const;

                std::string GetProjectBinDirectory () const;
                std::string GetProjectLibDirectory () const;
                std::string GetProjectIncludeDirectory () const;
                std::string GetProjectSrcDirectory () const;
                std::string GetProjectResourcesDirectory () const;
                std::string GetProjectTestsDirectory () const;
                std::string GetProjectDocDirectory () const;
                std::string GetProjectGoal () const;
                std::string GetProjectLinkLibrary () const;

                std::string GetToolchainConfigFile () const;
                std::string GetToolchainBinDirectory () const;
                std::string GetToolchainLibDirectory () const;
                std::string GetToolchainIncludeDirectory () const;
                std::string GetToolchainSrcDirectory () const;
                std::string GetToolchainResourcesDirectory () const;
                std::string GetToolchainTestsDirectory () const;
                std::string GetToolchainDocDirectory () const;
                std::string GetToolchainGoal () const;
                std::string GetToolchainLinkLibrary () const;

                void GetCommonPreprocessorDefinitions (std::set<std::string> &preprocessorDefinitions) const;
                std::string GetGoalFileName () const;

            private:
                thekogans_make (
                    const std::string &project_root_,
                    const std::string &config_file_,
                    const std::string &generator_,
                    const std::string &config_,
                    const std::string &type_);

                void Parseconstants (pugi::xml_node &node);
                void Parsedependencies (
                    pugi::xml_node &node,
                    std::vector<Dependency::SharedPtr> &dependencies);
                void Parsedependencyfeatures (
                    pugi::xml_node &node,
                    std::set<std::string> &features);
                void Parseset (
                    pugi::xml_node &node,
                    const std::string &name,
                    std::set<std::string> &set);
                void Parselist (
                    pugi::xml_node &node,
                    const std::string &name,
                    std::vector<std::string> &list);
                void ParseFileList (
                    pugi::xml_node &node,
                    const std::string &name,
                    FileList &fileList);
                void ParseFile (
                    pugi::xml_node &node,
                    FileList::File &file);
                void Parsecustom_build (
                    pugi::xml_node &node,
                    FileList &fileList);
                void Parseoutputs (
                    pugi::xml_node &node,
                    FileList &fileList,
                    FileList::File::CustomBuild &customBuild);
                void Parseprecompiled_header (
                    pugi::xml_node &node,
                    PrecompiledHeader &precompiledHeader);
                void Parsedependencies (
                    pugi::xml_node &node,
                    FileList &fileList,
                    FileList::File::CustomBuild &customBuild);
                void Parsebundle (
                    const pugi::xml_node &node,
                    pugi::xml_node &parent);
                bool Parseif (
                    const pugi::xml_node &node,
                    pugi::xml_node &parent);
                void Parsechoose (
                    const pugi::xml_node &node,
                    pugi::xml_node &parent);
                void ParseDefault (
                    const pugi::xml_node &node,
                    pugi::xml_node &parent);
                void CreateGlobalSymbolTable ();
                static void CreateDOM (
                    const std::string &project_root,
                    const std::string &config_file,
                    pugi::xml_document &document,
                    pugi::xml_node &root);

                THEKOGANS_UTIL_DISALLOW_COPY_AND_ASSIGN (thekogans_make)
            };

        } // namespace core
    } // namespace make
} // namespace thekogans

#endif // !defined (__thekogans_make_core_thekogans_make_h)

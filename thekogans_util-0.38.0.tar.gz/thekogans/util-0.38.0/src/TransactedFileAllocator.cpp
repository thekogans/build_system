// Copyright 2011 Boris Kogan (boris@thekogans.net)
//
// This file is part of libthekogans_util.
//
// libthekogans_util is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// libthekogans_util is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with libthekogans_util. If not, see <http://www.gnu.org/licenses/>.

#include "thekogans/util/Exception.h"
#include "thekogans/util/TransactedFile.h"
#if defined (THEKOGANS_UTIL_TYPE_Static)
    #include "thekogans/util/TransactedFileBTreeAllocator.h"
#endif // defined (THEKOGANS_UTIL_TYPE_Static)

namespace thekogans {
    namespace util {

        THEKOGANS_UTIL_IMPLEMENT_DYNAMIC_CREATABLE_ABSTRACT_BASE (
            thekogans::util::TransactedFile::Allocator)

    #if defined (THEKOGANS_UTIL_TYPE_Static)
        void TransactedFile::Allocator::StaticInit () {
            TransactedFileBTreeAllocator::StaticInit ();
        }
    #endif // defined (THEKOGANS_UTIL_TYPE_Static)

        void TransactedFile::Allocator::Block::Header::Read (
                TransactedFile &file,
                PtrType offset) {
            Range range (file, offset, SIZE);
        #if defined (THEKOGANS_UTIL_TRANSACTED_FILE_ALLOCATOR_BLOCK_USE_MAGIC)
            ui32 magic;
            range >> magic;
            if (magic == MAGIC32) {
        #endif // defined (THEKOGANS_UTIL_TRANSACTED_FILE_ALLOCATOR_BLOCK_USE_MAGIC)
                range >> flags >> size;
        #if defined (THEKOGANS_UTIL_TRANSACTED_FILE_ALLOCATOR_BLOCK_USE_MAGIC)
            }
            else {
                THEKOGANS_UTIL_THROW_STRING_EXCEPTION (
                    "Corrupt TransactedFile::Allocator::Block::Header @"
                    THEKOGANS_UTIL_UI64_FORMAT,
                    offset);
            }
        #endif // defined (THEKOGANS_UTIL_TRANSACTED_FILE_ALLOCATOR_BLOCK_USE_MAGIC)
        }

        void TransactedFile::Allocator::Block::Header::Write (
                TransactedFile &file,
                PtrType offset) const {
            Range range (file, offset, SIZE, false);
        #if defined (THEKOGANS_UTIL_TRANSACTED_FILE_ALLOCATOR_BLOCK_USE_MAGIC)
            range << MAGIC32;
        #endif // defined (THEKOGANS_UTIL_TRANSACTED_FILE_ALLOCATOR_BLOCK_USE_MAGIC)
            range << flags << size;
        }

        inline bool operator != (
                const TransactedFile::Allocator::Block::Header &header,
                const TransactedFile::Allocator::Block::Header &footer) {
            return header.flags != footer.flags || header.size != footer.size;
        }

        ui64 TransactedFile::Allocator::Block::GetSize (
                TransactedFile &file,
                PtrType offset) {
            Block block (file, offset);
            block.Read ();
            return block.GetSize ();
        }

        bool TransactedFile::Allocator::Block::Prev (Block &prev) const {
            if (!IsFirst ()) {
                Header footer;
                footer.Read (file, offset - SIZE);
                prev.offset = offset - SIZE - footer.size;
                prev.header.Read (file, prev.offset - HEADER_SIZE);
                if (prev.header != footer) {
                    THEKOGANS_UTIL_THROW_STRING_EXCEPTION (
                        "Corrupt TransactedFile::Allocator::Block @" THEKOGANS_UTIL_UI64_FORMAT "\n"
                        " prev.header.flags: %u prev.header.size: " THEKOGANS_UTIL_UI64_FORMAT "\n"
                        " prev.footer.flags: %u prev.footer.size: " THEKOGANS_UTIL_UI64_FORMAT,
                        prev.offset,
                        prev.header.flags, prev.header.size,
                        footer.flags, footer.size);
                }
                return true;
            }
            return false;
        }

        bool TransactedFile::Allocator::Block::Next (Block &next) const {
            if (!IsLast ()) {
                next.offset = offset + header.size + SIZE;
                next.Read ();
                return true;
            }
            return false;
        }

        void TransactedFile::Allocator::Block::Read () {
            header.Read (file, offset - HEADER_SIZE);
            Header footer;
            footer.Read (file, offset + header.size);
            if (header != footer) {
                THEKOGANS_UTIL_THROW_STRING_EXCEPTION (
                    "Corrupt TransactedFile::Allocator::Block @" THEKOGANS_UTIL_UI64_FORMAT "\n"
                    " header.flags: %u header.size: " THEKOGANS_UTIL_UI64_FORMAT "\n"
                    " footer.flags: %u footer.size: " THEKOGANS_UTIL_UI64_FORMAT,
                    offset,
                    header.flags, header.size,
                    footer.flags, footer.size);
            }
        }

        void TransactedFile::Allocator::Block::Write () const {
            header.Write (file, offset - HEADER_SIZE);
            header.Write (file, offset + header.size);
        }

        void TransactedFile::Allocator::Block::Clear () const {
            {
                Range range (file, offset - HEADER_SIZE, HEADER_SIZE, false);
                range.Seek (SecureZeroMemory (range.GetDataPtr (), range.GetDataAvailable ()), SEEK_CUR);
            }
            {
                Range range (file, offset + header.size, HEADER_SIZE, false);
                range.Seek (SecureZeroMemory (range.GetDataPtr (), range.GetDataAvailable ()), SEEK_CUR);
            }
        }

        inline Serializer &operator >> (
                Serializer &serializer,
                TransactedFile::Allocator::Header &header) {
            serializer >> header.flags >> header.registryOffset;
            return serializer;
        }

        void TransactedFile::Allocator::Read (
                const SerializableHeader & /*header_*/,
                Serializer &serializer) {
            ui32 magic;
            serializer >> magic;
            if (magic == MAGIC32) {
                serializer >> header;
            #if defined (THEKOGANS_UTIL_TRANSACTED_FILE_ALLOCATOR_BLOCK_USE_MAGIC)
                if (!header.IsBlockUsesMagic ()) {
            #else // defined (THEKOGANS_UTIL_TRANSACTED_FILE_ALLOCATOR_BLOCK_USE_MAGIC)
                if (header.IsBlockUsesMagic ()) {
            #endif // defined (THEKOGANS_UTIL_TRANSACTED_FILE_ALLOCATOR_BLOCK_USE_MAGIC)
                    THEKOGANS_UTIL_THROW_STRING_EXCEPTION (
                        "This TransactedFile::Allocator file cannot be opened by this version of %s.",
                        THEKOGANS_UTIL);
                }
            }
            else {
                THEKOGANS_UTIL_THROW_STRING_EXCEPTION (
                    "Corrupt TransactedFile::Allocator file.");
            }
        }

        inline Serializer &operator << (
                Serializer &serializer,
                const TransactedFile::Allocator::Header &header) {
            serializer << header.flags << header.registryOffset;
            return serializer;
        }

        void TransactedFile::Allocator::Write (Serializer &serializer) const {
            serializer << MAGIC32 << header;
        }

    } // namespace util
} // namespace thekogans
